export type UserRole = 'ADMIN' | 'RESCUE_TEAM' | 'DONOR' | 'VOLUNTEER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  location?: string;
  latitude?: number;
  longitude?: number;
  createdAt?: string;
}

export type ResourceType =
  | 'Food'
  | 'Drinking Water'
  | 'Medicine'
  | 'Clothing'
  | 'Blankets'
  | 'Hygiene'
  | 'Baby Supplies'
  | 'Emergency Equipment'
  | 'Shelter'
  | 'Other';

export type UrgencyLevel = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export interface Resource {
  id: string;
  donorId: string;
  donor?: User;
  resourceType: ResourceType;
  resourceName: string;
  quantity: number;
  availableQuantity: number;
  unit: string;
  availabilityDate: string;
  expiryDate?: string;
  locationName: string;
  latitude: number;
  longitude: number;
  description?: string;
  status: 'AVAILABLE' | 'RESERVED' | 'EXHAUSTED' | 'EXPIRED';
  createdAt: string;
  updatedAt?: string;
}

export interface EmergencyRequest {
  id: string;
  rescueTeamId: string;
  rescueTeam?: User;
  resourceType: ResourceType;
  resourceName: string;
  requiredQuantity: number;
  quantityRemaining: number;
  unit: string;
  affectedPeople: number;
  urgency: UrgencyLevel;
  disasterType?: string;
  disasterName?: string;
  requiredBy: string;
  locationName: string;
  latitude: number;
  longitude: number;
  description?: string;
  contactPerson?: string;
  contactNumber?: string;
  status: 'PENDING' | 'PARTIALLY_MATCHED' | 'FULLY_MATCHED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  createdAt: string;
  matches?: Match[];
}

export interface ScoreBreakdown {
  compatibilityScore: number;
  quantityScore: number;
  distanceScore: number;
  urgencyScore: number;
  deliveryTimeScore: number;
  totalScore: number;
}

export interface Match {
  id: string;
  requestId: string;
  request?: EmergencyRequest;
  resourceId: string;
  resource?: Resource;
  donorId: string;
  donor?: User;
  allocatedQuantity: number;
  matchScore: number;
  distance: number;
  estimatedDeliveryTime: number;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED' | 'FULFILLED';
  reason?: string;
  createdAt: string;
  delivery?: Delivery;
}

export interface Delivery {
  id: string;
  matchId: string;
  match?: Match;
  volunteerId?: string;
  volunteer?: User;
  pickupLocation: string;
  destination: string;
  distance: number;
  eta: number;
  status: 'PENDING' | 'ASSIGNED' | 'PICKED_UP' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  assignedAt?: string;
  pickedUpAt?: string;
  inTransitAt?: string;
  deliveredAt?: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface Disaster {
  id: string;
  name: string;
  type: string;
  description?: string;
  location: string;
  latitude: number;
  longitude: number;
  severity: UrgencyLevel;
  startDate: string;
  status: 'ACTIVE' | 'CONTAINED' | 'RESOLVED';
}

export interface AuditLog {
  id: string;
  userId?: string;
  user?: User;
  action: string;
  entity: string;
  entityId?: string;
  details?: string;
  createdAt: string;
}
