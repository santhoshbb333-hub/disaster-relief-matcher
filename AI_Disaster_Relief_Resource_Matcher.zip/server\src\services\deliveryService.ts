import { prisma } from '../utils/prisma.js';
import { sendNotification } from './notificationService.js';

export async function createDeliveryForMatch(matchId: string): Promise<any> {
  const match = await prisma.match.findUnique({
    where: { id: matchId },
    include: {
      request: true,
      resource: true,
      donor: true,
    },
  });

  if (!match) throw new Error('Match not found');

  // Check if delivery already exists
  const existingDelivery = await prisma.delivery.findUnique({
    where: { matchId },
  });

  if (existingDelivery) return existingDelivery;

  // Find an available volunteer
  const availableVolunteer = await prisma.user.findFirst({
    where: { role: 'VOLUNTEER' },
  });

  const delivery = await prisma.delivery.create({
    data: {
      matchId,
      volunteerId: availableVolunteer ? availableVolunteer.id : null,
      pickupLocation: match.resource.locationName,
      destination: match.request.locationName,
      distance: match.distance,
      eta: match.estimatedDeliveryTime,
      status: availableVolunteer ? 'ASSIGNED' : 'PENDING',
      assignedAt: availableVolunteer ? new Date() : null,
    },
  });

  if (availableVolunteer) {
    await sendNotification({
      userId: availableVolunteer.id,
      type: 'DELIVERY_ASSIGNED',
      title: '📦 NEW DELIVERY ASSIGNMENT',
      message: `You have been assigned to deliver ${match.allocatedQuantity} ${match.request.unit} of ${match.request.resourceName} from ${match.resource.locationName} to ${match.request.locationName}.`,
    });
  }

  return delivery;
}

export async function updateDeliveryStatus(
  deliveryId: string,
  newStatus: string,
  userId: string
): Promise<any> {
  const delivery = await prisma.delivery.findUnique({
    where: { id: deliveryId },
    include: {
      match: {
        include: {
          request: true,
          donor: true,
        },
      },
      volunteer: true,
    },
  });

  if (!delivery) throw new Error('Delivery not found');

  const updateData: any = { status: newStatus };

  if (newStatus === 'ASSIGNED' && !delivery.assignedAt) {
    updateData.assignedAt = new Date();
    updateData.volunteerId = userId;
  } else if (newStatus === 'PICKED_UP') {
    updateData.pickedUpAt = new Date();
  } else if (newStatus === 'IN_TRANSIT') {
    updateData.inTransitAt = new Date();
  } else if (newStatus === 'DELIVERED') {
    updateData.deliveredAt = new Date();
  }

  const updatedDelivery = await prisma.delivery.update({
    where: { id: deliveryId },
    data: updateData,
  });

  // Notify Rescue Team, Donor, and Volunteer
  const msgText = `Delivery for ${delivery.match.allocatedQuantity} ${delivery.match.request.unit} of ${delivery.match.request.resourceName} is now ${newStatus.replace('_', ' ')}.`;

  await sendNotification({
    userId: delivery.match.request.rescueTeamId,
    type: 'DELIVERY_STATUS',
    title: `🚚 Delivery Update: ${newStatus}`,
    message: msgText,
  });

  await sendNotification({
    userId: delivery.match.donorId,
    type: 'DELIVERY_STATUS',
    title: `🚚 Delivery Update: ${newStatus}`,
    message: msgText,
  });

  return updatedDelivery;
}
