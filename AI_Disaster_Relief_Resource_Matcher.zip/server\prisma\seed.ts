import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🧹 Purging all database tables for zero-state start...');
  await prisma.notification.deleteMany({});
  await prisma.auditLog.deleteMany({});
  await prisma.delivery.deleteMany({});
  await prisma.match.deleteMany({});
  await prisma.request.deleteMany({});
  await prisma.resource.deleteMany({});
  await prisma.disaster.deleteMany({});
  await prisma.user.deleteMany({});

  console.log('✅ Database is completely clean (0 requests, 0 resources, 0 matches, 0 deliveries).');
}

main()
  .catch((e) => {
    console.error('❌ Clean database error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
