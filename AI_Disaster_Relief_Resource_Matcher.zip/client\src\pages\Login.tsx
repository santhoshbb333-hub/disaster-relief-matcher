import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { HeartHandshake, ArrowRight, Lock, Mail, Shield } from 'lucide-react';

export const Login: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Invalid login credentials');
    } finally {
      setSubmitting(false);
    }
  };

  const autofillCredentials = (roleEmail: string) => {
    setEmail(roleEmail);
    setPassword('password123');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-2xl shadow-md">
            <HeartHandshake className="w-7 h-7" />
          </div>
        </div>
        <h2 className="mt-4 text-center text-2xl font-bold tracking-tight text-gray-900">
          AI DISASTER RELIEF RESOURCE MATCHER
        </h2>
        <p className="mt-1 text-center text-xs text-blue-700 font-semibold italic">
          “Right Resource. Right Place. Right Time.”
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 shadow-sm border border-gray-200 rounded-2xl sm:px-10">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs font-semibold text-red-700">
              {error}
            </div>
          )}

          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="rescue@relief.org"
                  className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 border border-transparent rounded-lg text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-sm transition-colors flex items-center justify-center"
            >
              {submitting ? 'Signing in...' : 'Sign In'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </form>

          {/* Preset Credentials */}
          <div className="mt-6 pt-5 border-t border-gray-100">
            <p className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2.5 flex items-center">
              <Shield className="w-3.5 h-3.5 mr-1.5 text-blue-600" />
              Quick Fill Demo Accounts
            </p>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => autofillCredentials('rescue@relief.org')}
                className="p-2 border border-gray-200 rounded-lg bg-gray-50 hover:bg-blue-50 hover:border-blue-200 text-left font-semibold text-gray-700 hover:text-blue-700 transition-colors"
              >
                Rescue Team
              </button>
              <button
                type="button"
                onClick={() => autofillCredentials('donorA@relief.org')}
                className="p-2 border border-gray-200 rounded-lg bg-gray-50 hover:bg-blue-50 hover:border-blue-200 text-left font-semibold text-gray-700 hover:text-blue-700 transition-colors"
              >
                Donor A
              </button>
              <button
                type="button"
                onClick={() => autofillCredentials('volunteer@relief.org')}
                className="p-2 border border-gray-200 rounded-lg bg-gray-50 hover:bg-blue-50 hover:border-blue-200 text-left font-semibold text-gray-700 hover:text-blue-700 transition-colors"
              >
                Volunteer
              </button>
              <button
                type="button"
                onClick={() => autofillCredentials('admin@relief.org')}
                className="p-2 border border-gray-200 rounded-lg bg-gray-50 hover:bg-blue-50 hover:border-blue-200 text-left font-semibold text-gray-700 hover:text-blue-700 transition-colors"
              >
                Admin
              </button>
            </div>
          </div>

          <div className="mt-4 text-center">
            <p className="text-xs text-gray-600">
              Don't have an account?{' '}
              <Link to="/register" className="font-semibold text-blue-600 hover:text-blue-700">
                Register here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
