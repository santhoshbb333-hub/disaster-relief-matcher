import { Router, Response } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticateToken, AuthenticatedRequest } from '../middleware/authMiddleware.js';
import { updateDeliveryStatus } from '../services/deliveryService.js';

const router = Router();

// List Deliveries
router.get('/', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { status, volunteerId } = req.query;

    const whereClause: any = {};
    if (status) whereClause.status = String(status);
    if (volunteerId) whereClause.volunteerId = String(volunteerId);

    // If logged in as VOLUNTEER, default to show assigned deliveries or unassigned pending deliveries
    if (req.user?.role === 'VOLUNTEER' && !volunteerId) {
      whereClause.OR = [
        { volunteerId: req.user.id },
        { volunteerId: null, status: 'PENDING' },
      ];
    }

    const deliveries = await prisma.delivery.findMany({
      where: whereClause,
      include: {
        match: {
          include: {
            request: {
              include: {
                rescueTeam: { select: { id: true, name: true, phone: true, email: true } },
              },
            },
            resource: {
              include: {
                donor: { select: { id: true, name: true, phone: true, email: true } },
              },
            },
          },
        },
        volunteer: { select: { id: true, name: true, phone: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ deliveries });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get Single Delivery by ID
router.get('/:id', async (req, res) => {
  try {
    const delivery = await prisma.delivery.findUnique({
      where: { id: req.params.id },
      include: {
        match: {
          include: {
            request: { include: { rescueTeam: true } },
            resource: { include: { donor: true } },
          },
        },
        volunteer: true,
      },
    });

    if (!delivery) {
      return res.status(404).json({ message: 'Delivery not found' });
    }

    res.json({ delivery });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Update Delivery Status (Volunteer / Admin workflow)
router.put('/:id/status', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { status } = req.body;
    if (!status) {
      return res.status(400).json({ message: 'New delivery status is required' });
    }

    const updatedDelivery = await updateDeliveryStatus(req.params.id, status, req.user!.id);

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'UPDATE_DELIVERY_STATUS',
        entity: 'DELIVERY',
        entityId: req.params.id,
        details: `Updated delivery status to ${status}`,
      },
    });

    res.json({
      message: `Delivery status updated to ${status}`,
      delivery: updatedDelivery,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
