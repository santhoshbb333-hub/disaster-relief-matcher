import React, { useEffect, useState } from 'react';
import { apiRequest } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { Link } from 'react-router-dom';
import { Package, Plus, Search, Filter } from 'lucide-react';
import { Resource } from '../types';

export const ResourcesList: React.FC = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  const fetchResources = async () => {
    try {
      const data = await apiRequest('/resources');
      setResources(data.resources || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResources();
  }, []);

  const filtered = resources.filter((r) => {
    const matchesSearch =
      r.resourceName.toLowerCase().includes(search.toLowerCase()) ||
      r.locationName.toLowerCase().includes(search.toLowerCase()) ||
      (r.donor?.name || '').toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter ? r.resourceType === typeFilter : true;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <Package className="w-5 h-5 text-purple-600 mr-2" />
            Available Donor Resources
          </h1>
          <p className="text-xs text-gray-500">
            Pledged relief supplies posted by individual, corporate, and NGO donors ready for AI matching.
          </p>
        </div>

        <Link
          to="/resources/create"
          className="inline-flex items-center justify-center px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4 mr-1.5" />
          Post Available Resource
        </Link>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-center gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by resource, donor, location..."
            className="w-full pl-9 pr-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 bg-white"
          >
            <option value="">All Categories</option>
            <option value="Food">Food</option>
            <option value="Drinking Water">Drinking Water</option>
            <option value="Medicine">Medicine</option>
            <option value="Clothing">Clothing</option>
            <option value="Blankets">Blankets</option>
            <option value="Hygiene">Hygiene</option>
            <option value="Baby Supplies">Baby Supplies</option>
            <option value="Emergency Equipment">Emergency Equipment</option>
            <option value="Shelter">Shelter</option>
          </select>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full p-8 text-center text-xs text-purple-600 font-semibold">Loading resources...</div>
        ) : filtered.length === 0 ? (
          <div className="col-span-full p-8 text-center text-xs text-gray-500">No resources match filters.</div>
        ) : (
          filtered.map((res) => (
            <div key={res.id} className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider bg-purple-50 px-2 py-0.5 rounded border border-purple-100">
                    {res.resourceType}
                  </span>
                  <h3 className="text-base font-bold text-gray-900 mt-1">{res.resourceName}</h3>
                </div>
                <StatusBadge status={res.status} type="match" />
              </div>

              <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-gray-400 font-semibold uppercase">Available Quantity</div>
                  <div className="text-lg font-black text-gray-900">
                    {res.availableQuantity} <span className="text-xs font-semibold text-gray-500">{res.unit}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-gray-400 font-semibold uppercase">Total Pledged</div>
                  <div className="text-xs font-bold text-gray-600">
                    {res.quantity} {res.unit}
                  </div>
                </div>
              </div>

              <div className="text-xs text-gray-600 space-y-1">
                <p>
                  <strong>Donor:</strong> {res.donor?.name || 'Anonymous Donor'}
                </p>
                <p>
                  <strong>Location:</strong> {res.locationName}
                </p>
                {res.description && <p className="text-gray-500 italic text-[11px]">{res.description}</p>}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
