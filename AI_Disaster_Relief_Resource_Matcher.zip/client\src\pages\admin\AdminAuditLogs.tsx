import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../services/api';
import { ShieldCheck, Clock } from 'lucide-react';
import { AuditLog } from '../../types';

export const AdminAuditLogs: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest('/analytics/audit-logs')
      .then((res) => setLogs(res.logs || []))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <h1 className="text-xl font-bold text-gray-900 flex items-center">
          <ShieldCheck className="w-5 h-5 text-emerald-600 mr-2" />
          System Audit Trail & Security Logs
        </h1>
        <p className="text-xs text-gray-500">
          Immutable audit record tracking resource creations, AI match acceptances, rejections, and volunteer status updates.
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-emerald-600 font-semibold">Loading audit logs...</div>
        ) : (
          <div className="divide-y divide-gray-100 text-xs">
            {logs.length === 0 ? (
              <div className="p-8 text-center text-xs text-gray-500">No audit log entries recorded yet.</div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="p-4 flex items-start justify-between hover:bg-gray-50/50">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-extrabold text-xs text-gray-900 bg-gray-100 px-2 py-0.5 rounded">
                        {log.action}
                      </span>
                      <span className="text-[11px] font-bold text-gray-500">
                        {log.user?.name || 'System User'} ({log.user?.role || 'SYSTEM'})
                      </span>
                    </div>
                    <p className="text-xs text-gray-700">{log.details}</p>
                  </div>
                  <div className="text-[10px] text-gray-400 flex items-center whitespace-nowrap">
                    <Clock className="w-3 h-3 mr-1" />
                    {new Date(log.createdAt).toLocaleString()}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
