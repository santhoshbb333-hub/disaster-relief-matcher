import React, { useEffect, useState } from 'react';
import { apiRequest } from '../services/api';
import { BarChart3, Download, FileSpreadsheet, FileText, CheckCircle2 } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export const ReportsPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest('/analytics/dashboard')
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  const handleExportCSV = () => {
    if (!data) return;
    const stats = data.summaryStats || {};

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Metric,Value\n';
    csvContent += `Total Requests,${stats.totalRequests || 0}\n`;
    csvContent += `Critical Requests,${stats.criticalRequests || 0}\n`;
    csvContent += `Fully Matched Requests,${stats.fullyMatchedRequests || 0}\n`;
    csvContent += `Partially Matched Requests,${stats.partiallyMatchedRequests || 0}\n`;
    csvContent += `Total Donor Resources,${stats.totalResources || 0}\n`;
    csvContent += `Active Deliveries,${stats.activeDeliveries || 0}\n`;
    csvContent += `Completed Deliveries,${stats.completedDeliveries || 0}\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `disaster_relief_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = async () => {
    const reportElement = document.getElementById('report-summary-content');
    if (!reportElement) return;

    const canvas = await html2canvas(reportElement);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`disaster_relief_summary_report_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  if (loading) {
    return <div className="p-8 text-center text-xs text-blue-600 font-semibold">Generating report metrics...</div>;
  }

  const stats = data?.summaryStats || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <BarChart3 className="w-5 h-5 text-blue-600 mr-2" />
            Disaster Relief System Analytics Report
          </h1>
          <p className="text-xs text-gray-500">
            Comprehensive operational metrics detailing resource allocation, match efficiency, and volunteer deliveries.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5" />
            Export CSV
          </button>

          <button
            onClick={handleExportPDF}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
          >
            <Download className="w-4 h-4 mr-1.5" />
            Export PDF
          </button>
        </div>
      </div>

      {/* Printable / Exportable Report Card */}
      <div id="report-summary-content" className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="border-b border-gray-100 pb-4 flex justify-between items-center">
          <div>
            <h2 className="text-lg font-bold text-gray-900">AI Disaster Relief Resource Matcher</h2>
            <p className="text-xs text-blue-700 font-semibold italic">“Right Resource. Right Place. Right Time.”</p>
          </div>
          <div className="text-right text-xs text-gray-400">
            Report Date: {new Date().toLocaleDateString()}
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
            <div className="text-[10px] text-gray-400 font-bold uppercase">Total Requests</div>
            <div className="text-2xl font-black text-gray-900 mt-1">{stats.totalRequests || 0}</div>
          </div>
          <div className="p-4 bg-red-50/60 rounded-xl border border-red-100">
            <div className="text-[10px] text-red-700 font-bold uppercase">Critical Requests</div>
            <div className="text-2xl font-black text-red-600 mt-1">{stats.criticalRequests || 0}</div>
          </div>
          <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-100">
            <div className="text-[10px] text-emerald-800 font-bold uppercase">Fully Matched</div>
            <div className="text-2xl font-black text-emerald-700 mt-1">{stats.fullyMatchedRequests || 0}</div>
          </div>
          <div className="p-4 bg-purple-50/60 rounded-xl border border-purple-100">
            <div className="text-[10px] text-purple-800 font-bold uppercase">Donor Inventory</div>
            <div className="text-2xl font-black text-purple-700 mt-1">{stats.totalResources || 0}</div>
          </div>
        </div>

        {/* Detailed Breakdown Tables */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-100">
          <div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-3">
              Requests by Urgency Distribution
            </h3>
            <div className="divide-y divide-gray-100 border border-gray-100 rounded-xl overflow-hidden text-xs">
              {(data?.charts?.requestsByUrgency || []).map((u: any) => (
                <div key={u.name} className="py-2.5 px-4 flex justify-between items-center">
                  <span className="font-semibold text-gray-800">{u.name}</span>
                  <span className="font-bold text-blue-700">{u.value} requests</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-3">
              Resource Inventory by Category
            </h3>
            <div className="divide-y divide-gray-100 border border-gray-100 rounded-xl overflow-hidden text-xs">
              {(data?.charts?.resourcesByType || []).map((r: any) => (
                <div key={r.name} className="py-2.5 px-4 flex justify-between items-center">
                  <span className="font-semibold text-gray-800">{r.name}</span>
                  <span className="font-bold text-purple-700">{r.quantity} available units</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
