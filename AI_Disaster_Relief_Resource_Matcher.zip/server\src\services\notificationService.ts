import { Server as SocketServer } from 'socket.io';
import { prisma } from '../utils/prisma.js';

let ioInstance: SocketServer | null = null;

export function setSocketServer(io: SocketServer): void {
  ioInstance = io;
}

export interface NotificationPayload {
  userId: string;
  type: string;
  title: string;
  message: string;
}

/**
 * Creates persistent Notification in Prisma DB and emits real-time WebSocket event via Socket.IO
 */
export async function sendNotification(payload: NotificationPayload) {
  try {
    const notification = await prisma.notification.create({
      data: {
        userId: payload.userId,
        type: payload.type,
        title: payload.title,
        message: payload.message,
      },
    });

    if (ioInstance) {
      // Emit to user room (user joins room matching their userId upon connecting)
      ioInstance.to(payload.userId).emit('notification', notification);
      ioInstance.to('all_users').emit('broadcast_update', { type: payload.type, notification });
    }

    return notification;
  } catch (error) {
    console.error('Error creating notification:', error);
    return null;
  }
}
