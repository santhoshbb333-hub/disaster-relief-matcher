import React from 'react';
import { WifiOff, RefreshCw, CheckCircle } from 'lucide-react';
import { useOfflineDrafts } from '../hooks/useOfflineDrafts';

export const OfflineBanner: React.FC = () => {
  const { isOnline, isSyncing, drafts, syncDrafts } = useOfflineDrafts();

  if (isOnline && drafts.length === 0 && !isSyncing) return null;

  return (
    <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-xs text-amber-800 flex items-center justify-between">
      <div className="flex items-center space-x-2">
        {!isOnline ? (
          <>
            <WifiOff className="w-4 h-4 text-amber-600 animate-pulse" />
            <span>
              <strong>Offline Mode Active:</strong> You are currently disconnected from network. New requests & resources will be saved as local drafts and auto-synced when online.
            </span>
          </>
        ) : isSyncing ? (
          <>
            <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />
            <span>
              <strong>Syncing Drafts:</strong> Uploading {drafts.length} pending draft item(s) to server...
            </span>
          </>
        ) : drafts.length > 0 ? (
          <>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>
              Network restored. You have {drafts.length} local draft item(s) ready to sync.
            </span>
          </>
        ) : null}
      </div>

      {isOnline && drafts.length > 0 && !isSyncing && (
        <button
          onClick={syncDrafts}
          className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-medium text-xs transition-colors"
        >
          Sync Now
        </button>
      )}
    </div>
  );
};
