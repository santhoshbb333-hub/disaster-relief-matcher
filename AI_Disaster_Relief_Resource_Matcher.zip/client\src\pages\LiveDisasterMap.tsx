import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { apiRequest } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { MapPin, RefreshCw, Truck } from 'lucide-react';

// Custom Leaflet Icons for clean color-coded markers
function createCustomMarker(color: string, label: string) {
  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: 2px solid white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 10px;
      ">
        ${label}
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
}

const reqCriticalIcon = createCustomMarker('#DC2626', 'REQ');
const reqHighIcon = createCustomMarker('#EA580C', 'REQ');
const reqMediumIcon = createCustomMarker('#EAB308', 'REQ');
const reqLowIcon = createCustomMarker('#16A34A', 'REQ');
const donorIcon = createCustomMarker('#2563EB', 'DNR');
const rescueCenterIcon = createCustomMarker('#9333EA', 'RSC');

export const LiveDisasterMap: React.FC = () => {
  const [mapData, setMapData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchMapData = async () => {
    setLoading(true);
    try {
      const res = await apiRequest('/map/data');
      setMapData(res);
    } catch (err) {
      console.error('Map fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMapData();
  }, []);

  const defaultCenter: [number, number] = [11.0168, 76.9558]; // Coimbatore central relief area

  return (
    <div className="space-y-6">
      {/* Map Header */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <MapPin className="w-5 h-5 text-red-600 mr-2" />
            Live Disaster Relief Spatial Map
          </h1>
          <p className="text-xs text-gray-500">
            Real-time GIS map displaying color-coded emergency requests, donor depots, rescue centers, and active volunteer delivery routes.
          </p>
        </div>

        <button
          onClick={fetchMapData}
          className="inline-flex items-center px-4 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 rounded-xl text-xs font-semibold transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Map
        </button>
      </div>

      {/* Legend Bar */}
      <div className="bg-white border border-gray-200 rounded-xl p-3 shadow-sm flex flex-wrap items-center gap-4 text-xs">
        <span className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">Map Legend:</span>
        <div className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-red-600 inline-block"></span>
          <span className="text-gray-700 font-semibold">Critical Request</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-orange-600 inline-block"></span>
          <span className="text-gray-700 font-semibold">High Priority</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-yellow-500 inline-block"></span>
          <span className="text-gray-700 font-semibold">Medium Priority</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-blue-600 inline-block"></span>
          <span className="text-gray-700 font-semibold">Donor Depot</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-purple-600 inline-block"></span>
          <span className="text-gray-700 font-semibold">Rescue Center</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-5 h-0.5 bg-amber-500 border-dashed border-t-2 border-amber-500 inline-block"></span>
          <span className="text-gray-700 font-semibold">Active Delivery Route</span>
        </div>
      </div>

      {/* Interactive Map Container */}
      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden h-[550px] relative">
        {loading ? (
          <div className="h-full flex items-center justify-center text-xs font-semibold text-blue-600">
            Loading spatial map markers...
          </div>
        ) : (
          <MapContainer center={defaultCenter} zoom={11} scrollWheelZoom={true} className="h-full w-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {/* Render Emergency Requests Markers */}
            {(mapData?.requests || []).map((req: any) => {
              let markerIcon = reqMediumIcon;
              if (req.urgency === 'CRITICAL') markerIcon = reqCriticalIcon;
              else if (req.urgency === 'HIGH') markerIcon = reqHighIcon;
              else if (req.urgency === 'LOW') markerIcon = reqLowIcon;

              return (
                <Marker key={req.id} position={[req.latitude, req.longitude]} icon={markerIcon}>
                  <Popup>
                    <div className="space-y-1.5 text-xs p-1">
                      <div className="flex items-center justify-between border-b pb-1">
                        <strong className="text-gray-900 font-bold">{req.resourceName}</strong>
                        <StatusBadge status={req.urgency} type="urgency" />
                      </div>
                      <p className="text-gray-600">
                        <strong>Required:</strong> {req.quantityRemaining} / {req.requiredQuantity} {req.unit}
                      </p>
                      <p className="text-gray-600">
                        <strong>Relief Base:</strong> {req.locationName}
                      </p>
                      <p className="text-gray-600">
                        <strong>Team:</strong> {req.rescueTeam?.name}
                      </p>
                    </div>
                  </Popup>
                </Marker>
              );
            })}

            {/* Render Donor Resource Markers */}
            {(mapData?.resources || []).map((res: any) => (
              <Marker key={res.id} position={[res.latitude, res.longitude]} icon={donorIcon}>
                <Popup>
                  <div className="space-y-1.5 text-xs p-1">
                    <div className="border-b pb-1">
                      <strong className="text-blue-700 font-bold">{res.resourceName}</strong>
                      <span className="ml-2 text-[10px] text-gray-500 font-normal">[{res.resourceType}]</span>
                    </div>
                    <p className="text-gray-700 font-semibold">
                      Available: {res.availableQuantity} {res.unit}
                    </p>
                    <p className="text-gray-600">
                      <strong>Donor Depot:</strong> {res.locationName}
                    </p>
                    <p className="text-gray-500">
                      <strong>Donor:</strong> {res.donor?.name}
                    </p>
                  </div>
                </Popup>
              </Marker>
            ))}

            {/* Render Active Delivery Route Lines */}
            {(mapData?.activeDeliveries || []).map((del: any) => {
              const resLat = del.match?.resource?.latitude;
              const resLng = del.match?.resource?.longitude;
              const reqLat = del.match?.request?.latitude;
              const reqLng = del.match?.request?.longitude;

              if (!resLat || !reqLat) return null;

              const routePositions: [number, number][] = [
                [resLat, resLng],
                [reqLat, reqLng],
              ];

              return (
                <React.Fragment key={del.id}>
                  <Polyline
                    positions={routePositions}
                    pathOptions={{ color: '#F59E0B', weight: 4, dashArray: '8, 8' }}
                  />
                  <Marker position={[ (resLat + reqLat) / 2, (resLng + reqLng) / 2 ]} icon={createCustomMarker('#F59E0B', 'TRK')}>
                    <Popup>
                      <div className="text-xs space-y-1 p-1">
                        <strong className="text-amber-700 flex items-center">
                          <Truck className="w-3.5 h-3.5 mr-1" /> Active Volunteer Delivery
                        </strong>
                        <p><strong>Item:</strong> {del.match?.allocatedQuantity} {del.match?.request?.unit} {del.match?.request?.resourceName}</p>
                        <p><strong>Distance:</strong> {del.distance} km (ETA: {del.eta} mins)</p>
                        <p><strong>Volunteer:</strong> {del.volunteer?.name || 'Assigned'}</p>
                      </div>
                    </Popup>
                  </Marker>
                </React.Fragment>
              );
            })}
          </MapContainer>
        )}
      </div>
    </div>
  );
};
