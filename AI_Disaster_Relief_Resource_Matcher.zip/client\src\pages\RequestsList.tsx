import React, { useEffect, useState } from 'react';
import { apiRequest } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { Link } from 'react-router-dom';
import { FileText, Plus, Search, Filter, Cpu, ArrowRight } from 'lucide-react';
import { EmergencyRequest } from '../types';

export const RequestsList: React.FC = () => {
  const [requests, setRequests] = useState<EmergencyRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const fetchRequests = async () => {
    try {
      const data = await apiRequest('/requests');
      setRequests(data.requests || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const filteredRequests = requests.filter((r) => {
    const matchesSearch =
      r.resourceName.toLowerCase().includes(search.toLowerCase()) ||
      r.locationName.toLowerCase().includes(search.toLowerCase()) ||
      (r.rescueTeam?.name || '').toLowerCase().includes(search.toLowerCase());
    const matchesUrgency = urgencyFilter ? r.urgency === urgencyFilter : true;
    const matchesStatus = statusFilter ? r.status === statusFilter : true;
    return matchesSearch && matchesUrgency && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <FileText className="w-5 h-5 text-blue-600 mr-2" />
            Emergency Resource Requests
          </h1>
          <p className="text-xs text-gray-500">
            Real-time status of emergency requirements logged by relief centers and rescue teams.
          </p>
        </div>

        <Link
          to="/requests/create"
          className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4 mr-1.5" />
          Create Resource Request
        </Link>
      </div>

      {/* Filter Bar */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-center gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by resource, location..."
            className="w-full pl-9 pr-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={urgencyFilter}
            onChange={(e) => setUrgencyFilter(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 bg-white"
          >
            <option value="">All Urgency Levels</option>
            <option value="CRITICAL">CRITICAL</option>
            <option value="HIGH">HIGH</option>
            <option value="MEDIUM">MEDIUM</option>
            <option value="LOW">LOW</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 bg-white"
          >
            <option value="">All Statuses</option>
            <option value="PENDING">PENDING</option>
            <option value="PARTIALLY_MATCHED">PARTIALLY MATCHED</option>
            <option value="FULLY_MATCHED">FULLY MATCHED</option>
          </select>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-blue-600 font-semibold">Loading requests...</div>
        ) : filteredRequests.length === 0 ? (
          <div className="p-8 text-center text-xs text-gray-500">No emergency requests match filters.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-[11px] font-bold uppercase tracking-wider text-gray-500">
                  <th className="py-3 px-4">Resource & Category</th>
                  <th className="py-3 px-4">Required / Remaining</th>
                  <th className="py-3 px-4">Urgency</th>
                  <th className="py-3 px-4">Relief Center / Location</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-xs text-gray-800">
                {filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-gray-50/70 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-gray-900">
                      <div>{req.resourceName}</div>
                      <div className="text-[10px] text-gray-400 font-normal">{req.resourceType}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold">
                      <span className="text-blue-700">{req.quantityRemaining}</span> / {req.requiredQuantity} {req.unit}
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusBadge status={req.urgency} type="urgency" />
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-gray-900">{req.rescueTeam?.name || 'Relief Team'}</div>
                      <div className="text-[10px] text-gray-500">{req.locationName}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusBadge status={req.status} type="request" />
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <Link
                        to={`/ai-matching/${req.id}`}
                        className="inline-flex items-center px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Cpu className="w-3.5 h-3.5 mr-1" />
                        AI Matches
                        <ArrowRight className="w-3 h-3 ml-1" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
