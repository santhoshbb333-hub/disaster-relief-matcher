import { useState, useEffect } from 'react';
import { apiRequest } from '../services/api';

export interface DraftItem {
  id: string;
  type: 'REQUEST' | 'RESOURCE';
  data: any;
  createdAt: string;
}

export function useOfflineDrafts() {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [drafts, setDrafts] = useState<DraftItem[]>([]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncDrafts();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Load initial drafts from LocalStorage
    const saved = localStorage.getItem('disaster_relief_drafts');
    if (saved) {
      try {
        setDrafts(JSON.parse(saved));
      } catch (err) {
        console.error('Failed to parse drafts:', err);
      }
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const saveDraft = (type: 'REQUEST' | 'RESOURCE', data: any) => {
    const newDraft: DraftItem = {
      id: 'draft_' + Date.now(),
      type,
      data,
      createdAt: new Date().toISOString(),
    };

    const updated = [...drafts, newDraft];
    setDrafts(updated);
    localStorage.setItem('disaster_relief_drafts', JSON.stringify(updated));
    return newDraft;
  };

  const syncDrafts = async () => {
    const saved = localStorage.getItem('disaster_relief_drafts');
    if (!saved) return;

    try {
      const pendingDrafts: DraftItem[] = JSON.parse(saved);
      if (pendingDrafts.length === 0) return;

      setIsSyncing(true);

      const remainingDrafts: DraftItem[] = [];

      for (const draft of pendingDrafts) {
        try {
          if (draft.type === 'REQUEST') {
            await apiRequest('/requests', {
              method: 'POST',
              body: JSON.stringify(draft.data),
            });
          } else if (draft.type === 'RESOURCE') {
            await apiRequest('/resources', {
              method: 'POST',
              body: JSON.stringify(draft.data),
            });
          }
        } catch (err) {
          console.error(`Failed to sync draft ${draft.id}:`, err);
          remainingDrafts.push(draft);
        }
      }

      setDrafts(remainingDrafts);
      localStorage.setItem('disaster_relief_drafts', JSON.stringify(remainingDrafts));
    } finally {
      setIsSyncing(false);
    }
  };

  return {
    isOnline,
    isSyncing,
    drafts,
    saveDraft,
    syncDrafts,
  };
}
