import { Router } from 'express';
import { prisma } from '../utils/prisma.js';

const router = Router();

// Get Live Disaster Map Data
router.get('/data', async (req, res) => {
  try {
    const [requests, resources, activeDeliveries, disasters] = await Promise.all([
      prisma.request.findMany({
        where: { status: { in: ['PENDING', 'PARTIALLY_MATCHED', 'FULLY_MATCHED', 'IN_PROGRESS'] } },
        include: { rescueTeam: { select: { name: true, phone: true } } },
      }),
      prisma.resource.findMany({
        where: { availableQuantity: { gt: 0 } },
        include: { donor: { select: { name: true, phone: true } } },
      }),
      prisma.delivery.findMany({
        where: { status: { in: ['ASSIGNED', 'PICKED_UP', 'IN_TRANSIT'] } },
        include: {
          match: {
            include: {
              request: true,
              resource: true,
              donor: true,
            },
          },
          volunteer: true,
        },
      }),
      prisma.disaster.findMany({
        where: { status: 'ACTIVE' },
      }),
    ]);

    res.json({
      requests,
      resources,
      activeDeliveries,
      disasters,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
