import React from 'react';
import { MapPin, ShieldCheck, X } from 'lucide-react';

interface LocationPermissionModalProps {
  isOpen: boolean;
  onAllow: () => void;
  onDeny: () => void;
}

export const LocationPermissionModal: React.FC<LocationPermissionModalProps> = ({
  isOpen,
  onAllow,
  onDeny,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/40 backdrop-blur-xs p-4">
      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-xl max-w-sm w-full space-y-4">
        <div className="flex items-center justify-between">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <MapPin className="w-6 h-6" />
          </div>
          <button onClick={onDeny} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div>
          <h3 className="text-base font-bold text-gray-900">Allow location access?</h3>
          <p className="text-xs text-gray-500 mt-1 leading-relaxed">
            The application uses your GPS location to calculate accurate distance and delivery ETAs to emergency rescue centers. Your location is never tracked continuously or shared without your permission.
          </p>
        </div>

        <div className="pt-2 flex items-center justify-end space-x-2">
          <button
            type="button"
            onClick={onDeny}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-semibold transition-colors"
          >
            Not Now
          </button>
          <button
            type="button"
            onClick={onAllow}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center"
          >
            <ShieldCheck className="w-3.5 h-3.5 mr-1" />
            Allow Location
          </button>
        </div>
      </div>
    </div>
  );
};
