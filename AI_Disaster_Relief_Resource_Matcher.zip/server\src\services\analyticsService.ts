import { prisma } from '../utils/prisma.js';

export async function getDashboardAnalytics() {
  const [
    totalUsers,
    totalDonors,
    totalRescueTeams,
    totalVolunteers,
    totalResources,
    totalRequests,
    criticalRequests,
    pendingRequests,
    fullyMatchedRequests,
    partiallyMatchedRequests,
    activeMatches,
    activeDeliveries,
    completedDeliveries,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { role: 'DONOR' } }),
    prisma.user.count({ where: { role: 'RESCUE_TEAM' } }),
    prisma.user.count({ where: { role: 'VOLUNTEER' } }),
    prisma.resource.count(),
    prisma.request.count(),
    prisma.request.count({ where: { urgency: 'CRITICAL' } }),
    prisma.request.count({ where: { status: 'PENDING' } }),
    prisma.request.count({ where: { status: 'FULLY_MATCHED' } }),
    prisma.request.count({ where: { status: 'PARTIALLY_MATCHED' } }),
    prisma.match.count({ where: { status: 'ACCEPTED' } }),
    prisma.delivery.count({ where: { status: { in: ['ASSIGNED', 'PICKED_UP', 'IN_TRANSIT'] } } }),
    prisma.delivery.count({ where: { status: 'DELIVERED' } }),
  ]);

  // Aggregate Requests by Urgency
  const requestsByUrgencyRaw = await prisma.request.groupBy({
    by: ['urgency'],
    _count: { urgency: true },
  });
  const requestsByUrgency = requestsByUrgencyRaw.map((item) => ({
    name: item.urgency,
    value: item._count.urgency,
  }));

  // Aggregate Resources by Type
  const resourcesByTypeRaw = await prisma.resource.groupBy({
    by: ['resourceType'],
    _count: { resourceType: true },
    _sum: { availableQuantity: true },
  });
  const resourcesByType = resourcesByTypeRaw.map((item) => ({
    name: item.resourceType,
    count: item._count.resourceType,
    quantity: item._sum.availableQuantity || 0,
  }));

  // Aggregate Deliveries by Status
  const deliveriesByStatusRaw = await prisma.delivery.groupBy({
    by: ['status'],
    _count: { status: true },
  });
  const deliveriesByStatus = deliveriesByStatusRaw.map((item) => ({
    name: item.status.replace('_', ' '),
    count: item._count.status,
  }));

  // Recent Requests & Matches
  const recentRequests = await prisma.request.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: { rescueTeam: true },
  });

  const recentResources = await prisma.resource.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: { donor: true },
  });

  const recentDeliveries = await prisma.delivery.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: {
      match: {
        include: {
          request: true,
          donor: true,
        },
      },
      volunteer: true,
    },
  });

  return {
    summaryStats: {
      totalUsers,
      totalDonors,
      totalRescueTeams,
      totalVolunteers,
      totalResources,
      totalRequests,
      criticalRequests,
      pendingRequests,
      fullyMatchedRequests,
      partiallyMatchedRequests,
      activeMatches,
      activeDeliveries,
      completedDeliveries,
    },
    charts: {
      requestsByUrgency,
      resourcesByType,
      deliveriesByStatus,
    },
    tables: {
      recentRequests,
      recentResources,
      recentDeliveries,
    },
  };
}
