import React, { useState } from 'react';
import { apiRequest } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { useOfflineDrafts } from '../hooks/useOfflineDrafts';
import { Package, Cpu, ArrowRight } from 'lucide-react';
import { ResourceType } from '../types';

export const PostResource: React.FC = () => {
  const navigate = useNavigate();
  const { isOnline, saveDraft } = useOfflineDrafts();

  const [resourceType, setResourceType] = useState<ResourceType>('Food');
  const [resourceName, setResourceName] = useState('Rice Packets');
  const [quantity, setQuantity] = useState('700');
  const [unit, setUnit] = useState('Packets');
  const [availabilityDate, setAvailabilityDate] = useState(new Date().toISOString().slice(0, 16));
  const [expiryDate, setExpiryDate] = useState('');
  const [locationName, setLocationName] = useState('Coimbatore East Depot');
  const [latitude, setLatitude] = useState('11.0500');
  const [longitude, setLongitude] = useState('77.0100');
  const [description, setDescription] = useState('Freshly sealed 1kg emergency ration rice packets ready for immediate dispatch.');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const payload = {
      resourceType,
      resourceName,
      quantity: parseInt(quantity, 10),
      unit,
      availabilityDate,
      expiryDate: expiryDate || null,
      locationName,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
      description,
    };

    if (!isOnline) {
      saveDraft('RESOURCE', payload);
      setSubmitting(false);
      alert('Network is offline. Resource saved as local draft!');
      navigate('/resources');
      return;
    }

    try {
      await apiRequest('/resources', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      alert('Available resource posted successfully! AI matching triggered for pending rescue requests.');
      navigate('/resources');
    } catch (err: any) {
      setError(err.message || 'Failed to post resource');
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 border-b border-gray-100 pb-4">
          <div className="p-2.5 bg-purple-50 text-purple-600 rounded-xl">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">Post Available Resource</h1>
            <p className="text-xs text-gray-500">
              List relief resources ready for dispatch. AI will match your donation to active emergency rescue requests.
            </p>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs font-semibold text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Resource Type</label>
              <select
                value={resourceType}
                onChange={(e) => setResourceType(e.target.value as ResourceType)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500 bg-white font-semibold"
              >
                <option value="Food">Food</option>
                <option value="Drinking Water">Drinking Water</option>
                <option value="Medicine">Medicine</option>
                <option value="Clothing">Clothing</option>
                <option value="Blankets">Blankets</option>
                <option value="Hygiene">Hygiene</option>
                <option value="Baby Supplies">Baby Supplies</option>
                <option value="Emergency Equipment">Emergency Equipment</option>
                <option value="Shelter">Shelter</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Resource Name (Specific Item)</label>
              <input
                type="text"
                required
                value={resourceName}
                onChange={(e) => setResourceName(e.target.value)}
                placeholder="e.g. Rice Packets, First Aid Kits, Bottled Water"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Available Quantity</label>
              <input
                type="number"
                required
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500 font-bold text-purple-700"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Measurement Unit</label>
              <input
                type="text"
                required
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="Packets, Bottles, Kits"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Availability Date/Time</label>
              <input
                type="datetime-local"
                value={availabilityDate}
                onChange={(e) => setAvailabilityDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-gray-700 mb-1">Pickup Location Name</label>
              <input
                type="text"
                required
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                placeholder="Coimbatore East Depot, Warehouse 4"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Expiry Date (Optional)</label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Latitude</label>
              <input
                type="text"
                required
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Longitude</label>
              <input
                type="text"
                required
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono text-gray-900 focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Item Description & Pickup Notes</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="pt-4 border-t border-gray-100 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/resources')}
              className="px-4 py-2 border border-gray-300 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
            >
              <Cpu className="w-4 h-4 mr-2" />
              {submitting ? 'Posting...' : 'Post Resource & Trigger Matching'}
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
