import { Router, Response } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticateToken, AuthenticatedRequest } from '../middleware/authMiddleware.js';
import { triggerMatchingForPendingRequests } from '../services/aiMatchingService.js';

const router = Router();

// Post Available Resource
router.post('/', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      resourceType,
      resourceName,
      quantity,
      unit,
      availabilityDate,
      expiryDate,
      locationName,
      latitude,
      longitude,
      description,
    } = req.body;

    if (!resourceType || !resourceName || !quantity || !unit || !locationName) {
      return res.status(400).json({ message: 'Missing required resource fields' });
    }

    const qty = parseInt(quantity, 10);
    const lat = latitude ? parseFloat(latitude) : req.user?.latitude || 11.0168;
    const lng = longitude ? parseFloat(longitude) : req.user?.longitude || 76.9558;

    const resource = await prisma.resource.create({
      data: {
        donorId: req.user!.id,
        resourceType,
        resourceName,
        quantity: qty,
        availableQuantity: qty,
        unit,
        availabilityDate: availabilityDate ? new Date(availabilityDate) : new Date(),
        expiryDate: expiryDate ? new Date(expiryDate) : null,
        locationName,
        latitude: lat,
        longitude: lng,
        description: description || '',
        status: 'AVAILABLE',
      },
    });

    // Create Audit Log entry
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'POST_RESOURCE',
        entity: 'RESOURCE',
        entityId: resource.id,
        details: `Posted ${qty} ${unit} of ${resourceName} at ${locationName}`,
      },
    });

    // Trigger AI matching automatically across all pending rescue requests
    triggerMatchingForPendingRequests().catch((err) =>
      console.error('Auto matching trigger error:', err)
    );

    res.status(201).json({
      message: 'Resource posted successfully',
      resource,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to post resource' });
  }
});

// List Resources with Filters
router.get('/', async (req, res) => {
  try {
    const { status, resourceType, donorId } = req.query;

    const whereClause: any = {};
    if (status) whereClause.status = String(status);
    if (resourceType) whereClause.resourceType = String(resourceType);
    if (donorId) whereClause.donorId = String(donorId);

    const resources = await prisma.resource.findMany({
      where: whereClause,
      include: {
        donor: {
          select: { id: true, name: true, email: true, phone: true, location: true },
        },
        matches: {
          include: {
            request: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ resources });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get Resource by ID
router.get('/:id', async (req, res) => {
  try {
    const resource = await prisma.resource.findUnique({
      where: { id: req.params.id },
      include: {
        donor: true,
        matches: {
          include: {
            request: true,
          },
        },
      },
    });

    if (!resource) {
      return res.status(404).json({ message: 'Resource not found' });
    }

    res.json({ resource });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Update Resource Quantity / Details
router.put('/:id', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { availableQuantity, status, description } = req.body;
    const updateData: any = {};
    if (availableQuantity !== undefined) updateData.availableQuantity = parseInt(availableQuantity, 10);
    if (status) updateData.status = status;
    if (description !== undefined) updateData.description = description;

    const updated = await prisma.resource.update({
      where: { id: req.params.id },
      data: updateData,
    });

    // Trigger auto re-matching
    triggerMatchingForPendingRequests().catch(console.error);

    res.json({ resource: updated });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Resource
router.delete('/:id', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await prisma.resource.delete({ where: { id: req.params.id } });
    res.json({ message: 'Resource deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
