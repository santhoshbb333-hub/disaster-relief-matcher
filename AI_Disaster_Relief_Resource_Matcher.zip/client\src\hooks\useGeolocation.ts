import { useState } from 'react';

export interface LocationPermissionState {
  hasRequested: boolean;
  isGranted: boolean;
  latitude: number | null;
  longitude: number | null;
  error: string | null;
}

export function useGeolocation() {
  const [geoState, setGeoState] = useState<LocationPermissionState>({
    hasRequested: false,
    isGranted: false,
    latitude: null,
    longitude: null,
    error: null,
  });

  const requestLocationPermission = (): Promise<{ latitude: number; longitude: number } | null> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        setGeoState({
          hasRequested: true,
          isGranted: false,
          latitude: null,
          longitude: null,
          error: 'Geolocation is not supported by your browser.',
        });
        resolve(null);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          setGeoState({
            hasRequested: true,
            isGranted: true,
            latitude: lat,
            longitude: lng,
            error: null,
          });
          resolve({ latitude: lat, longitude: lng });
        },
        (err) => {
          setGeoState({
            hasRequested: true,
            isGranted: false,
            latitude: null,
            longitude: null,
            error: err.message || 'Location permission denied.',
          });
          resolve(null);
        }
      );
    });
  };

  const denyLocationPermission = () => {
    setGeoState({
      hasRequested: true,
      isGranted: false,
      latitude: null,
      longitude: null,
      error: 'User denied location permission.',
    });
  };

  return {
    geoState,
    requestLocationPermission,
    denyLocationPermission,
  };
}
