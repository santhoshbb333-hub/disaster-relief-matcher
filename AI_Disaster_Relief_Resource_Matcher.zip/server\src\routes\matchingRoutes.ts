import { Router, Response } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticateToken, AuthenticatedRequest } from '../middleware/authMiddleware.js';
import { runAiMatchingForRequest } from '../services/aiMatchingService.js';
import { createDeliveryForMatch } from '../services/deliveryService.js';
import { sendNotification } from '../services/notificationService.js';

const router = Router();

// Re-run AI Matching for a specific request
router.post('/request/:requestId', async (req, res) => {
  try {
    const result = await runAiMatchingForRequest(req.params.requestId);
    if (!result) {
      return res.status(404).json({ message: 'Request not found' });
    }
    res.json({ result });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get Matches for a specific request
router.get('/request/:requestId', async (req, res) => {
  try {
    const matches = await prisma.match.findMany({
      where: { requestId: req.params.requestId },
      include: {
        donor: { select: { id: true, name: true, email: true, phone: true, location: true } },
        resource: true,
        delivery: true,
      },
      orderBy: { matchScore: 'desc' },
    });

    res.json({ matches });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// ACCEPT AI MATCH (Donor Accept Workflow)
router.post('/:matchId/accept', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { matchId } = req.params;

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      include: {
        request: true,
        resource: true,
        donor: true,
      },
    });

    if (!match) {
      return res.status(404).json({ message: 'Match not found' });
    }

    if (match.status === 'ACCEPTED') {
      return res.status(400).json({ message: 'Match has already been accepted' });
    }

    // Execute Prisma Transaction for atomic quantity reservation
    const { updatedMatch, updatedResource, updatedRequest } = await prisma.$transaction(async (tx) => {
      // 1. Verify and decrement donor resource available quantity
      const targetResource = await tx.resource.findUnique({ where: { id: match.resourceId } });
      if (!targetResource || targetResource.availableQuantity < match.allocatedQuantity) {
        throw new Error(`Insufficient donor quantity available (Required: ${match.allocatedQuantity}, Available: ${targetResource?.availableQuantity || 0})`);
      }

      const newAvailableQty = targetResource.availableQuantity - match.allocatedQuantity;
      const resStatus = newAvailableQty === 0 ? 'RESERVED' : 'AVAILABLE';

      const updatedRes = await tx.resource.update({
        where: { id: match.resourceId },
        data: {
          availableQuantity: newAvailableQty,
          status: resStatus,
        },
      });

      // 2. Verify and decrement request remaining quantity
      const targetReq = await tx.request.findUnique({ where: { id: match.requestId } });
      const currentRemaining = targetReq?.quantityRemaining || 0;
      const newRemaining = Math.max(0, currentRemaining - match.allocatedQuantity);
      const reqStatus = newRemaining === 0 ? 'FULLY_MATCHED' : 'PARTIALLY_MATCHED';

      const updatedReq = await tx.request.update({
        where: { id: match.requestId },
        data: {
          quantityRemaining: newRemaining,
          status: reqStatus,
        },
      });

      // 3. Mark Match as ACCEPTED
      const updatedM = await tx.match.update({
        where: { id: matchId },
        data: { status: 'ACCEPTED' },
      });

      return {
        updatedMatch: updatedM,
        updatedResource: updatedRes,
        updatedRequest: updatedReq,
      };
    });

    // Create delivery task and assign available volunteer
    const delivery = await createDeliveryForMatch(matchId);

    // Create Audit Log entry
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'ACCEPT_MATCH',
        entity: 'MATCH',
        entityId: matchId,
        details: `Donor ${match.donor.name} accepted match #${matchId.slice(0, 8)} allocating ${match.allocatedQuantity} units.`,
      },
    });

    // Notify Rescue Team that match was accepted
    await sendNotification({
      userId: match.request.rescueTeamId,
      type: 'MATCH_ACCEPTED',
      title: '🎉 MATCH ACCEPTED BY DONOR',
      message: `${match.donor.name} accepted request #${match.requestId.slice(0, 8)}: ${match.allocatedQuantity} ${match.request.unit} reserved and assigned for delivery!`,
    });

    res.json({
      message: 'Match accepted successfully. Resource reserved & delivery initiated.',
      match: updatedMatch,
      resource: updatedResource,
      request: updatedRequest,
      delivery,
    });
  } catch (error: any) {
    res.status(400).json({ message: error.message || 'Failed to accept match' });
  }
});

// REJECT AI MATCH (Donor Reject Workflow & Auto Re-matching)
router.post('/:matchId/reject', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { matchId } = req.params;
    const { reason } = req.body;

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      include: {
        request: true,
        donor: true,
      },
    });

    if (!match) {
      return res.status(404).json({ message: 'Match not found' });
    }

    // Mark Match as REJECTED
    const updatedMatch = await prisma.match.update({
      where: { id: matchId },
      data: {
        status: 'REJECTED',
        reason: reason ? `Donor Rejected: ${reason}` : 'Donor declined match allocation.',
      },
    });

    // Audit Log
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'REJECT_MATCH',
        entity: 'MATCH',
        entityId: matchId,
        details: `Donor ${match.donor.name} rejected match #${matchId.slice(0, 8)}. Reason: ${reason || 'None provided'}.`,
      },
    });

    // Notify Rescue Team that match was rejected
    await sendNotification({
      userId: match.request.rescueTeamId,
      type: 'MATCH_REJECTED',
      title: '⚠️ MATCH DECLINED BY DONOR',
      message: `Donor ${match.donor.name} declined match for request #${match.requestId.slice(0, 8)}. Re-triggering AI matching for alternative donors...`,
    });

    // Automatically re-run AI matching engine to find next candidate donor resources
    const newAiResults = await runAiMatchingForRequest(match.requestId);

    res.json({
      message: 'Match rejected. Quantity kept available & AI re-matching executed.',
      match: updatedMatch,
      newMatches: newAiResults,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to reject match' });
  }
});

export default router;
