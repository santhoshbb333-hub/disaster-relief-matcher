import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../services/api';
import { Users } from 'lucide-react';
import { User } from '../../types';

export const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest('/analytics/users')
      .then((res: any) => setUsers(res.users || []))
      .catch((err: any) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <h1 className="text-xl font-bold text-gray-900 flex items-center">
          <Users className="w-5 h-5 text-purple-600 mr-2" />
          Admin User Role Management
        </h1>
        <p className="text-xs text-gray-500">
          Monitor and manage registered system accounts across Admin, Rescue Team, Donor, and Volunteer roles.
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-purple-600 font-semibold">Loading users...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-[11px] font-bold uppercase tracking-wider text-gray-500">
                  <th className="py-3 px-4">User Name & Email</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Phone Number</th>
                  <th className="py-3 px-4">Base Location</th>
                  <th className="py-3 px-4">Coordinates</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-xs text-gray-800">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-gray-50/70">
                    <td className="py-3.5 px-4 font-semibold text-gray-900">
                      <div>{u.name}</div>
                      <div className="text-[10px] text-gray-400 font-normal">{u.email}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-purple-700">
                      <span className="bg-purple-50 text-purple-700 px-2 py-0.5 rounded border border-purple-100 text-[11px]">
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">{u.phone || 'N/A'}</td>
                    <td className="py-3.5 px-4">{u.location || 'Coimbatore'}</td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500">
                      {u.latitude?.toFixed(4)}, {u.longitude?.toFixed(4)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
