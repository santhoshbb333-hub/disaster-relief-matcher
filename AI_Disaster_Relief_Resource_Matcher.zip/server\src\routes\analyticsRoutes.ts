import { Router, Response } from 'express';
import { prisma } from '../utils/prisma.js';
import { getDashboardAnalytics } from '../services/analyticsService.js';
import { authenticateToken, authorizeRoles, AuthenticatedRequest } from '../middleware/authMiddleware.js';

const router = Router();

// Dashboard Analytics Data
router.get('/dashboard', async (req, res) => {
  try {
    const data = await getDashboardAnalytics();
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Admin Users List
router.get('/users', authenticateToken, authorizeRoles('ADMIN'), async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        phone: true,
        location: true,
        latitude: true,
        longitude: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ users });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Admin Audit Logs
router.get('/audit-logs', authenticateToken, authorizeRoles('ADMIN'), async (req, res) => {
  try {
    const logs = await prisma.auditLog.findMany({
      include: {
        user: { select: { name: true, email: true, role: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json({ logs });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Disasters List & Creation
router.get('/disasters', async (req, res) => {
  try {
    const disasters = await prisma.disaster.findMany({
      orderBy: { createdAt: 'desc' },
    });
    res.json({ disasters });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/disasters', authenticateToken, authorizeRoles('ADMIN'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, type, description, location, latitude, longitude, severity } = req.body;
    const disaster = await prisma.disaster.create({
      data: {
        name,
        type: type || 'Emergency',
        description,
        location,
        latitude: latitude ? parseFloat(latitude) : 11.0168,
        longitude: longitude ? parseFloat(longitude) : 76.9558,
        severity: severity || 'HIGH',
        status: 'ACTIVE',
      },
    });

    res.status(201).json({ disaster });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
