import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { useAuth } from '../contexts/AuthContext';
import {
  Cpu,
  MapPin,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Info,
} from 'lucide-react';
import { EmergencyRequest, Match } from '../types';

export const AiMatchingPage: React.FC = () => {
  const { requestId } = useParams<{ requestId?: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [requestsList, setRequestsList] = useState<EmergencyRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<EmergencyRequest | null>(null);
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingMatchId, setProcessingMatchId] = useState<string | null>(null);

  // Load request and matches
  const loadData = async (reqId?: string) => {
    setLoading(true);
    try {
      const reqRes = await apiRequest('/requests');
      const allReqs: EmergencyRequest[] = reqRes.requests || [];
      setRequestsList(allReqs);

      let targetReq = reqId ? allReqs.find((r) => r.id === reqId) : allReqs[0];
      if (!targetReq && allReqs.length > 0) targetReq = allReqs[0];

      if (targetReq) {
        setSelectedRequest(targetReq);
        const matchRes = await apiRequest(`/matching/request/${targetReq.id}`);
        setMatches(matchRes.matches || []);
      }
    } catch (err) {
      console.error('Error fetching AI matches:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData(requestId);
  }, [requestId]);

  const handleSelectRequest = (id: string) => {
    navigate(`/ai-matching/${id}`);
  };

  const handleTriggerReMatch = async () => {
    if (!selectedRequest) return;
    setLoading(true);
    try {
      await apiRequest(`/matching/request/${selectedRequest.id}`, { method: 'POST' });
      await loadData(selectedRequest.id);
    } catch (err: any) {
      alert(err.message || 'Matching error');
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptMatch = async (matchId: string) => {
    setProcessingMatchId(matchId);
    try {
      const res = await apiRequest(`/matching/${matchId}/accept`, { method: 'POST' });
      alert(res.message || 'Match Accepted! Resource reserved & delivery initiated.');
      await loadData(selectedRequest?.id);
    } catch (err: any) {
      alert(err.message || 'Failed to accept match');
    } finally {
      setProcessingMatchId(null);
    }
  };

  const handleRejectMatch = async (matchId: string) => {
    const reason = prompt('Optional reason for rejecting this match allocation:');
    setProcessingMatchId(matchId);
    try {
      const res = await apiRequest(`/matching/${matchId}/reject`, {
        method: 'POST',
        body: JSON.stringify({ reason }),
      });
      alert(res.message || 'Match rejected. AI re-matching executed for remaining candidate donors.');
      await loadData(selectedRequest?.id);
    } catch (err: any) {
      alert(err.message || 'Failed to reject match');
    } finally {
      setProcessingMatchId(null);
    }
  };

  const totalAllocated = matches
    .filter((m) => m.status !== 'REJECTED')
    .reduce((sum, m) => sum + m.allocatedQuantity, 0);

  const reqQty = selectedRequest?.requiredQuantity || 0;
  const remainingQty = selectedRequest ? Math.max(0, selectedRequest.quantityRemaining) : 0;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-1 px-2.5 py-0.5 bg-blue-50 text-blue-700 rounded-md text-[11px] font-bold border border-blue-100 mb-1">
            <Sparkles className="w-3 h-3 text-blue-600" />
            <span>DYNAMIC 5-FACTOR MATCHING ENGINE</span>
          </div>
          <h1 className="text-xl font-bold text-gray-900">AI Disaster Relief Resource Matching</h1>
          <p className="text-xs text-gray-500">
            Intelligently pairs emergency requests with optimal single or multi-donor resources based on actual location distance, quantity, urgency, and availability.
          </p>
        </div>

        {selectedRequest && (
          <button
            onClick={handleTriggerReMatch}
            disabled={loading}
            className="inline-flex items-center px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Re-Run AI Matcher
          </button>
        )}
      </div>

      {/* Select Request Dropdown */}
      {requestsList.length > 0 && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm flex items-center space-x-3">
          <label className="text-xs font-bold text-gray-700 whitespace-nowrap">Select Emergency Request:</label>
          <select
            value={selectedRequest?.id || ''}
            onChange={(e) => handleSelectRequest(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold text-gray-900 bg-white focus:ring-2 focus:ring-blue-500"
          >
            {requestsList.map((r) => (
              <option key={r.id} value={r.id}>
                #{r.id.slice(0, 8)} — {r.resourceName} ({r.requiredQuantity} {r.unit}) [{r.urgency}] — {r.locationName}
              </option>
            ))}
          </select>
        </div>
      )}

      {loading ? (
        <div className="p-12 text-center text-xs text-blue-600 font-semibold space-y-2">
          <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <div>Running AI Matching Engine analysis against donor inventory...</div>
        </div>
      ) : !selectedRequest ? (
        <div className="p-12 bg-white border border-gray-200 rounded-2xl text-center text-xs text-gray-500">
          No emergency requests found. Submit a request to view AI matching analysis.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Request Details & Final Allocation Summary */}
          <div className="space-y-6">
            {/* Selected Request Card */}
            <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                <span className="text-[11px] font-mono text-gray-400 font-bold">REQ #{selectedRequest.id.slice(0, 8)}</span>
                <StatusBadge status={selectedRequest.urgency} type="urgency" />
              </div>

              <div>
                <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                  {selectedRequest.resourceType}
                </span>
                <h2 className="text-lg font-bold text-gray-900 mt-1">{selectedRequest.resourceName}</h2>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-100">
                  <div className="text-[10px] text-gray-400 font-bold uppercase">Required Quantity</div>
                  <div className="text-base font-extrabold text-gray-900">
                    {selectedRequest.requiredQuantity} <span className="text-xs text-gray-500 font-normal">{selectedRequest.unit}</span>
                  </div>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-100">
                  <div className="text-[10px] text-gray-400 font-bold uppercase">Remaining Unmatched</div>
                  <div className="text-base font-extrabold text-blue-700">
                    {selectedRequest.quantityRemaining} <span className="text-xs text-gray-500 font-normal">{selectedRequest.unit}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-gray-600 space-y-1 pt-2 border-t border-gray-100">
                <p className="flex items-center">
                  <MapPin className="w-3.5 h-3.5 text-gray-400 mr-1.5" />
                  <strong>Location:</strong> {selectedRequest.locationName}
                </p>
                <p className="flex items-center">
                  <Clock className="w-3.5 h-3.5 text-gray-400 mr-1.5" />
                  <strong>Rescue Team:</strong> {selectedRequest.rescueTeam?.name || 'Relief Center'}
                </p>
                <p className="flex items-center text-amber-700 font-medium">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 mr-1.5" />
                  <strong>Affected People:</strong> {selectedRequest.affectedPeople} victims
                </p>
              </div>
            </div>

            {/* Final Allocation Summary Card */}
            <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-900 border-b border-gray-100 pb-2 flex items-center">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 mr-1.5" />
                AI Allocation Summary
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Required Quantity:</span>
                  <span className="font-bold text-gray-900">{reqQty} {selectedRequest.unit}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">AI Allocated Quantity:</span>
                  <span className="font-bold text-emerald-700">{totalAllocated} {selectedRequest.unit}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Remaining Deficit:</span>
                  <span className="font-bold text-blue-700">{remainingQty} {selectedRequest.unit}</span>
                </div>
                <div className="flex justify-between items-center py-2 pt-3">
                  <span className="font-bold text-gray-700">Request Status:</span>
                  <StatusBadge status={selectedRequest.status} type="request" />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: AI Recommended Donor Allocations */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-gray-900 flex items-center">
                <Cpu className="w-4 h-4 text-blue-600 mr-2" />
                AI RECOMMENDED DONOR ALLOCATIONS ({matches.length})
              </h2>
            </div>

            {matches.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-2xl p-8 text-center text-xs text-gray-500 space-y-2">
                <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
                <p className="font-semibold text-gray-800">No compatible donor resources found in range.</p>
                <p>When a donor posts a matching resource, the AI Engine will re-run automatically.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {matches.map((match, index) => {
                  const isDonorOwner = user?.id === match.donorId || user?.role === 'ADMIN';

                  return (
                    <div
                      key={match.id}
                      className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4 hover:border-blue-300 transition-colors"
                    >
                      {/* Match Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-extrabold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                              Donor #{index + 1} Candidate
                            </span>
                            <span className="text-sm font-bold text-gray-900">{match.donor?.name || 'Donor'}</span>
                            <StatusBadge status={match.status} type="match" />
                          </div>
                          <p className="text-[11px] text-gray-500 mt-0.5">
                            Resource: <strong>{match.resource?.resourceName || match.request?.resourceName}</strong>
                          </p>
                        </div>

                        {/* Dynamic AI Score */}
                        <div className="text-right">
                          <div className="text-[10px] text-gray-400 font-bold uppercase">Dynamic Match Score</div>
                          <div className="text-xl font-black text-blue-700">{match.matchScore}%</div>
                        </div>
                      </div>

                      {/* Allocation Details */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                        <div className="p-2 bg-gray-50 rounded-lg">
                          <div className="text-[10px] text-gray-400 font-bold uppercase">Available</div>
                          <div className="font-bold text-gray-900">
                            {match.resource?.availableQuantity || match.allocatedQuantity} {selectedRequest.unit}
                          </div>
                        </div>

                        <div className="p-2 bg-blue-50/70 rounded-lg border border-blue-100">
                          <div className="text-[10px] text-blue-800 font-bold uppercase">AI Suggested Qty</div>
                          <div className="font-extrabold text-blue-700">
                            {match.allocatedQuantity} {selectedRequest.unit}
                          </div>
                        </div>

                        <div className="p-2 bg-gray-50 rounded-lg">
                          <div className="text-[10px] text-gray-400 font-bold uppercase">Distance</div>
                          <div className="font-bold text-gray-900 flex items-center">
                            <MapPin className="w-3 h-3 text-gray-400 mr-1" />
                            {match.distance} km
                          </div>
                        </div>

                        <div className="p-2 bg-gray-50 rounded-lg">
                          <div className="text-[10px] text-gray-400 font-bold uppercase">Est. Delivery</div>
                          <div className="font-bold text-gray-900 flex items-center">
                            <Clock className="w-3 h-3 text-gray-400 mr-1" />
                            {match.estimatedDeliveryTime} mins
                          </div>
                        </div>
                      </div>

                      {/* Human-Readable AI Explanation */}
                      {match.reason && (
                        <div className="p-3 bg-blue-50/50 border border-blue-100 rounded-xl text-xs text-blue-900 flex items-start space-x-2">
                          <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <strong className="font-semibold text-blue-900">AI Selection Explanation:</strong>
                            <p className="mt-0.5 text-[11px] text-blue-800 leading-relaxed">{match.reason}</p>
                          </div>
                        </div>
                      )}

                      {/* Accept / Reject Action Buttons */}
                      {match.status === 'PENDING' && (
                        <div className="pt-2 flex items-center justify-between border-t border-gray-100">
                          <span className="text-[11px] text-gray-500 italic">
                            {isDonorOwner
                              ? 'You have been selected by AI for this allocation.'
                              : `Awaiting action from ${match.donor?.name}`}
                          </span>

                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => handleRejectMatch(match.id)}
                              disabled={processingMatchId === match.id}
                              className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-semibold transition-colors flex items-center"
                            >
                              <XCircle className="w-3.5 h-3.5 mr-1" />
                              Reject
                            </button>

                            <button
                              onClick={() => handleAcceptMatch(match.id)}
                              disabled={processingMatchId === match.id}
                              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                              {processingMatchId === match.id ? 'Processing...' : 'Accept Match'}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
