import React, { useState } from 'react';
import { useSocket } from '../contexts/SocketContext';
import { apiRequest } from '../services/api';
import { Bell, CheckCheck, Circle, Clock } from 'lucide-react';

export const NotificationsPage: React.FC = () => {
  const { notifications, unreadCount, refreshNotifications } = useSocket();
  const [tab, setTab] = useState<'ALL' | 'UNREAD' | 'READ'>('ALL');

  const handleMarkRead = async (id: string) => {
    try {
      await apiRequest(`/notifications/${id}/read`, { method: 'PUT' });
      refreshNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await apiRequest('/notifications/read-all', { method: 'PUT' });
      refreshNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const filtered = notifications.filter((n) => {
    if (tab === 'UNREAD') return !n.isRead;
    if (tab === 'READ') return n.isRead;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <Bell className="w-5 h-5 text-blue-600 mr-2" />
            Relief Notification Center
          </h1>
          <p className="text-xs text-gray-500">
            Real-time updates regarding AI match allocations, donor acceptances, and volunteer delivery statuses.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="px-3.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold transition-colors flex items-center"
          >
            <CheckCheck className="w-3.5 h-3.5 mr-1.5" />
            Mark All as Read ({unreadCount})
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 space-x-4">
        <button
          onClick={() => setTab('ALL')}
          className={`pb-2 text-xs font-bold transition-colors ${
            tab === 'ALL' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          All ({notifications.length})
        </button>
        <button
          onClick={() => setTab('UNREAD')}
          className={`pb-2 text-xs font-bold transition-colors ${
            tab === 'UNREAD' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          Unread ({unreadCount})
        </button>
        <button
          onClick={() => setTab('READ')}
          className={`pb-2 text-xs font-bold transition-colors ${
            tab === 'READ' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          Read ({notifications.length - unreadCount})
        </button>
      </div>

      {/* Notifications List */}
      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm divide-y divide-gray-100 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-xs text-gray-500">No notifications in this view.</div>
        ) : (
          filtered.map((n) => (
            <div
              key={n.id}
              className={`p-4 flex items-start justify-between transition-colors ${
                !n.isRead ? 'bg-blue-50/40' : 'bg-white'
              }`}
            >
              <div className="flex items-start space-x-3">
                <Circle className={`w-2.5 h-2.5 mt-1.5 flex-shrink-0 ${!n.isRead ? 'text-blue-600 fill-blue-600' : 'text-transparent'}`} />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-gray-900">{n.title}</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">{n.message}</p>
                  <div className="text-[10px] text-gray-400 flex items-center pt-1">
                    <Clock className="w-3 h-3 mr-1" />
                    {new Date(n.createdAt).toLocaleString()}
                  </div>
                </div>
              </div>

              {!n.isRead && (
                <button
                  onClick={() => handleMarkRead(n.id)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-blue-700 bg-white border border-blue-200 rounded-lg hover:bg-blue-50"
                >
                  Mark Read
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
