import { prisma } from '../utils/prisma.js';
import { calculateHaversineDistance, estimateTravelTimeMinutes } from './distanceService.js';
import { sendNotification } from './notificationService.js';

export interface ScoreBreakdown {
  compatibilityScore: number; // 30% weight
  quantityScore: number;      // 20% weight
  distanceScore: number;      // 20% weight
  urgencyScore: number;       // 15% weight
  deliveryTimeScore: number;  // 15% weight
  totalScore: number;         // 100% total
}

export interface MatchAllocationResult {
  matchId?: string;
  donorId: string;
  donorName: string;
  resourceId: string;
  resourceName: string;
  allocatedQuantity: number;
  availableQuantity: number;
  matchScore: number;
  scoreBreakdown: ScoreBreakdown;
  distance: number;
  estimatedDeliveryTime: number;
  reason: string;
}

export interface MatchingEngineResult {
  requestId: string;
  requiredQuantity: number;
  allocatedQuantityTotal: number;
  remainingQuantity: number;
  status: 'FULLY_MATCHED' | 'PARTIALLY_MATCHED' | 'PENDING';
  allocations: MatchAllocationResult[];
  explanationSummary: string;
}

/**
 * Calculates string similarity / compatibility between request resource name/type and donor resource name/type
 */
function calculateResourceCompatibility(
  reqType: string,
  reqName: string,
  donorType: string,
  donorName: string
): number {
  const normReqType = reqType.trim().toLowerCase();
  const normReqName = reqName.trim().toLowerCase();
  const normDonorType = donorType.trim().toLowerCase();
  const normDonorName = donorName.trim().toLowerCase();

  if (normReqType !== normDonorType) {
    return 0; // Cross-category items do not match
  }

  // Same category exact item name
  if (normReqName === normDonorName) {
    return 100;
  }

  // One contains the other (e.g. "Water Bottles" vs "Drinking Water Bottles")
  if (normReqName.includes(normDonorName) || normDonorName.includes(normReqName)) {
    return 85;
  }

  // Same category, general item match (e.g. "Food" category items)
  return 65;
}

/**
 * Calculates urgency score (15% weight component)
 */
function calculateUrgencyScore(urgency: string): number {
  switch (urgency.toUpperCase()) {
    case 'CRITICAL':
      return 100;
    case 'HIGH':
      return 85;
    case 'MEDIUM':
      return 70;
    case 'LOW':
      return 50;
    default:
      return 70;
  }
}

/**
 * Runs the AI Matching Engine for a specific Emergency Request
 */
export async function runAiMatchingForRequest(requestId: string): Promise<MatchingEngineResult | null> {
  const request = await prisma.request.findUnique({
    where: { id: requestId },
    include: { rescueTeam: true },
  });

  if (!request) return null;

  // Fetch available donor resources matching resourceType and with availableQuantity > 0
  const candidateResources = await prisma.resource.findMany({
    where: {
      resourceType: request.resourceType,
      availableQuantity: { gt: 0 },
      status: 'AVAILABLE',
    },
    include: { donor: true },
  });

  if (candidateResources.length === 0) {
    return {
      requestId: request.id,
      requiredQuantity: request.requiredQuantity,
      allocatedQuantityTotal: 0,
      remainingQuantity: request.quantityRemaining,
      status: request.quantityRemaining < request.requiredQuantity ? 'PARTIALLY_MATCHED' : 'PENDING',
      allocations: [],
      explanationSummary: `No available donor resources found matching requested category "${request.resourceType}".`,
    };
  }

  // Evaluate candidate scores dynamically
  const scoredCandidates = candidateResources
    .map((resource) => {
      const compatibility = calculateResourceCompatibility(
        request.resourceType,
        request.resourceName,
        resource.resourceType,
        resource.resourceName
      );

      if (compatibility === 0) return null; // Skip incompatible items

      const distance = calculateHaversineDistance(
        request.latitude,
        request.longitude,
        resource.latitude,
        resource.longitude
      );

      const etaMinutes = estimateTravelTimeMinutes(distance);

      // Distance score decay: 100% at 0km, -1.25% per km, floor at 10%
      const distanceScore = Math.max(10, Math.round((100 - distance * 1.25) * 10) / 10);

      // Quantity score relative to request remaining quantity
      const reqRemaining = request.quantityRemaining > 0 ? request.quantityRemaining : request.requiredQuantity;
      const quantityMatchRatio = Math.min(1.0, resource.availableQuantity / reqRemaining);
      const quantityScore = Math.round(quantityMatchRatio * 100);

      const urgencyScore = calculateUrgencyScore(request.urgency);

      // Delivery time score based on immediate availability and ETA
      const isImmediate = new Date(resource.availabilityDate) <= new Date();
      let deliveryTimeScore = isImmediate ? 95 : 60;
      if (etaMinutes < 30) deliveryTimeScore += 5;

      // Composite dynamic score (30% comp + 20% qty + 20% dist + 15% urg + 15% del)
      const totalScore = Math.round(
        (compatibility * 0.30 +
          quantityScore * 0.20 +
          distanceScore * 0.20 +
          urgencyScore * 0.15 +
          deliveryTimeScore * 0.15) * 10
      ) / 10;

      const breakdown: ScoreBreakdown = {
        compatibilityScore: compatibility,
        quantityScore,
        distanceScore,
        urgencyScore,
        deliveryTimeScore,
        totalScore,
      };

      return {
        resource,
        distance,
        etaMinutes,
        scoreBreakdown: breakdown,
        totalScore,
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null);

  // Sort candidates by total score descending (highest score first)
  scoredCandidates.sort((a, b) => b.totalScore - a.totalScore);

  // Multi-donor greedy allocation algorithm
  let remainingToAllocate = request.quantityRemaining > 0 ? request.quantityRemaining : request.requiredQuantity;
  let totalAllocated = 0;
  const allocations: MatchAllocationResult[] = [];

  for (const candidate of scoredCandidates) {
    if (remainingToAllocate <= 0) break;

    const available = candidate.resource.availableQuantity;
    const allocateQty = Math.min(available, remainingToAllocate);

    if (allocateQty > 0) {
      remainingToAllocate -= allocateQty;
      totalAllocated += allocateQty;

      // Generate clear human-readable AI explanation text
      const reason = `${candidate.resource.donor.name} selected: Exact item match ("${candidate.resource.resourceName}"), ${allocateQty} ${request.unit} allocated (${candidate.resource.availableQuantity} available), located ${candidate.distance} km away with estimated ETA of ${candidate.etaMinutes} mins.`;

      allocations.push({
        donorId: candidate.resource.donorId,
        donorName: candidate.resource.donor.name,
        resourceId: candidate.resource.id,
        resourceName: candidate.resource.resourceName,
        allocatedQuantity: allocateQty,
        availableQuantity: candidate.resource.availableQuantity,
        matchScore: candidate.totalScore,
        scoreBreakdown: candidate.scoreBreakdown,
        distance: candidate.distance,
        estimatedDeliveryTime: candidate.etaMinutes,
        reason,
      });
    }
  }

  const finalRemaining = Math.max(0, (request.quantityRemaining || request.requiredQuantity) - totalAllocated);
  const newStatus = finalRemaining === 0 ? 'FULLY_MATCHED' : totalAllocated > 0 ? 'PARTIALLY_MATCHED' : request.status;

  // Persist / update Match entries in Prisma DB
  // Clean up any existing unaccepted PENDING matches for this request before inserting new AI matches
  await prisma.match.deleteMany({
    where: {
      requestId: request.id,
      status: 'PENDING',
    },
  });

  const createdAllocations: MatchAllocationResult[] = [];

  for (const alloc of allocations) {
    const createdMatch = await prisma.match.create({
      data: {
        requestId: request.id,
        resourceId: alloc.resourceId,
        donorId: alloc.donorId,
        allocatedQuantity: alloc.allocatedQuantity,
        matchScore: alloc.matchScore,
        distance: alloc.distance,
        estimatedDeliveryTime: alloc.estimatedDeliveryTime,
        status: 'PENDING',
        reason: alloc.reason,
      },
    });

    createdAllocations.push({
      ...alloc,
      matchId: createdMatch.id,
    });

    // Notify Donor about the new AI Match
    await sendNotification({
      userId: alloc.donorId,
      type: 'AI_MATCH',
      title: `🚨 NEW AI RESOURCE MATCH (${alloc.matchScore}% Score)`,
      message: `You have been selected to provide ${alloc.allocatedQuantity} ${request.unit} of ${request.resourceName} for emergency request #${request.id.slice(0, 8)}. Destination: ${request.locationName} (${alloc.distance} km away).`,
    });
  }

  // Update request status in DB
  await prisma.request.update({
    where: { id: request.id },
    data: {
      status: newStatus,
    },
  });

  // Build summary explanation
  let explanationSummary = '';
  if (allocations.length === 1) {
    explanationSummary = `1 donor selected satisfying ${totalAllocated} / ${request.requiredQuantity} ${request.unit}.`;
  } else if (allocations.length > 1) {
    explanationSummary = `Multi-donor match executed: ${allocations.length} donors combined to satisfy ${totalAllocated} / ${request.requiredQuantity} ${request.unit}.`;
  } else {
    explanationSummary = `AI analyzed candidate donors but could not fulfill requirement.`;
  }

  return {
    requestId: request.id,
    requiredQuantity: request.requiredQuantity,
    allocatedQuantityTotal: totalAllocated,
    remainingQuantity: finalRemaining,
    status: newStatus as any,
    allocations: createdAllocations,
    explanationSummary,
  };
}

/**
 * Automatically triggers AI matching engine for all pending requests when a new donor resource is posted or updated
 */
export async function triggerMatchingForPendingRequests(): Promise<void> {
  const pendingRequests = await prisma.request.findMany({
    where: {
      status: { in: ['PENDING', 'PARTIALLY_MATCHED'] },
      quantityRemaining: { gt: 0 },
    },
    select: { id: true },
  });

  for (const req of pendingRequests) {
    await runAiMatchingForRequest(req.id);
  }
}
