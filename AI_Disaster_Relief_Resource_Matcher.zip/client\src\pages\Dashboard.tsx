import React, { useEffect, useState } from 'react';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { apiRequest } from '../services/api';
import { Link } from 'react-router-dom';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  Package,
  Truck,
  Cpu,
  PlusCircle,
  Clock,
  ArrowRight,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      const res = await apiRequest('/analytics/dashboard');
      setData(res);
    } catch (err) {
      console.error('Failed to load dashboard analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center space-x-2 text-blue-600 font-semibold text-xs">
        <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        <span>Loading AI Relief Dashboard...</span>
      </div>
    );
  }

  const stats = data?.summaryStats || {};

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-white border border-gray-200 rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-blue-50 border border-blue-200 rounded-full text-[11px] font-bold text-blue-700">
            <Cpu className="w-3.5 h-3.5 text-blue-600" />
            <span>AI RESOURCE MATCHING PLATFORM</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">
            Connect Emergency Rescue Requirements With Donor Supplies
          </h1>

          <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
            Real-time AI matching matches rescue teams with available donors based on resource category, item name, required quantity, location distance, urgency, and delivery timeframe.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <Link
              to="/requests/create"
              className="inline-flex items-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4 mr-2" />
              Create Requirement (Rescue Team)
            </Link>

            <Link
              to="/resources/create"
              className="inline-flex items-center px-4 py-2.5 bg-gray-900 hover:bg-black text-white rounded-xl font-semibold text-xs shadow-xs transition-colors"
            >
              <Package className="w-4 h-4 mr-2" />
              Post Available Resource (Donor)
            </Link>
          </div>
        </div>
      </div>

      {/* Real Database Statistics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard
          title="Total Requests"
          value={stats.totalRequests || 0}
          subtitle={stats.totalRequests ? `${stats.pendingRequests || 0} pending` : 'No resource requests yet.'}
          icon={FileText}
          iconBgColor="bg-blue-50"
          iconTextColor="text-blue-600"
        />
        <StatCard
          title="Available Donor Resources"
          value={stats.totalResources || 0}
          subtitle={stats.totalResources ? 'Ready for dispatch' : 'No available donor resources yet.'}
          icon={Package}
          iconBgColor="bg-purple-50"
          iconTextColor="text-purple-600"
        />
        <StatCard
          title="Active AI Matches"
          value={stats.activeMatches || 0}
          subtitle={stats.activeMatches ? 'Matches reserved' : 'No AI matches yet.'}
          icon={Cpu}
          iconBgColor="bg-emerald-50"
          iconTextColor="text-emerald-600"
        />
        <StatCard
          title="Critical Requests"
          value={stats.criticalRequests || 0}
          subtitle="Highest AI priority"
          icon={AlertTriangle}
          iconBgColor="bg-red-50"
          iconTextColor="text-red-600"
        />
        <StatCard
          title="Active Deliveries"
          value={stats.activeDeliveries || 0}
          subtitle={stats.activeDeliveries ? 'Deliveries in progress' : 'No active deliveries.'}
          icon={Truck}
          iconBgColor="bg-amber-50"
          iconTextColor="text-amber-600"
        />
        <StatCard
          title="Completed Deliveries"
          value={stats.completedDeliveries || 0}
          subtitle="Successfully delivered to rescue team"
          icon={CheckCircle2}
          iconBgColor="bg-blue-50"
          iconTextColor="text-blue-600"
        />
      </div>

      {/* Database Content Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Requests */}
        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <h2 className="text-sm font-bold text-gray-900 flex items-center">
              <FileText className="w-4 h-4 text-blue-600 mr-2" />
              Emergency Resource Requests ({stats.totalRequests || 0})
            </h2>
            <Link to="/requests" className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center">
              View All <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </div>

          {(data?.tables?.recentRequests || []).length === 0 ? (
            <div className="py-10 text-center text-xs text-gray-500 bg-gray-50/50 rounded-xl border border-dashed border-gray-200">
              <p className="font-semibold text-gray-700">No resource requests yet.</p>
              <p className="mt-1">When a rescue team creates a request, it will appear here.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {(data?.tables?.recentRequests || []).map((req: any) => (
                <div key={req.id} className="py-3 flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-gray-900">{req.resourceName}</span>
                      <StatusBadge status={req.urgency} type="urgency" />
                      <StatusBadge status={req.status} type="request" />
                    </div>
                    <p className="text-[11px] text-gray-500">
                      {req.requiredQuantity} {req.unit} • Location: {req.locationName}
                    </p>
                  </div>

                  <Link
                    to={`/ai-matching/${req.id}`}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold transition-colors"
                  >
                    AI Matches
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Available Resources */}
        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <h2 className="text-sm font-bold text-gray-900 flex items-center">
              <Package className="w-4 h-4 text-purple-600 mr-2" />
              Available Donor Resources ({stats.totalResources || 0})
            </h2>
            <Link to="/resources" className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center">
              View All <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Link>
          </div>

          {(data?.tables?.recentResources || []).length === 0 ? (
            <div className="py-10 text-center text-xs text-gray-500 bg-gray-50/50 rounded-xl border border-dashed border-gray-200">
              <p className="font-semibold text-gray-700">No available donor resources yet.</p>
              <p className="mt-1">When a donor posts an available item, it will appear here.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {(data?.tables?.recentResources || []).map((res: any) => (
                <div key={res.id} className="py-3 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-gray-900">{res.resourceName}</span>
                    <p className="text-[11px] text-gray-500">{res.locationName}</p>
                  </div>
                  <span className="text-xs font-bold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-100">
                    {res.availableQuantity} {res.unit}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
