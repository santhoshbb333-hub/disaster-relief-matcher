import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './AuthContext';
import { NotificationItem } from '../types';
import { apiRequest } from '../services/api';

interface SocketContextType {
  socket: Socket | null;
  notifications: NotificationItem[];
  unreadCount: number;
  toastMessage: { title: string; message: string; type: string } | null;
  clearToast: () => void;
  refreshNotifications: () => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export const SocketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<{ title: string; message: string; type: string } | null>(null);

  const fetchNotifications = async () => {
    if (!user) return;
    try {
      const data = await apiRequest('/notifications');
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [user]);

  useEffect(() => {
    if (!user) return;

    const newSocket = io('/', {
      transports: ['websocket', 'polling'],
    });

    setSocket(newSocket);

    newSocket.on('connect', () => {
      newSocket.emit('join_user', user.id);
    });

    newSocket.on('notification', (newNotif: NotificationItem) => {
      setNotifications((prev) => [newNotif, ...prev]);
      setUnreadCount((prev) => prev + 1);
      setToastMessage({
        title: newNotif.title,
        message: newNotif.message,
        type: newNotif.type,
      });
    });

    newSocket.on('broadcast_update', () => {
      fetchNotifications();
    });

    return () => {
      newSocket.disconnect();
    };
  }, [user]);

  const clearToast = () => setToastMessage(null);

  return (
    <SocketContext.Provider
      value={{
        socket,
        notifications,
        unreadCount,
        toastMessage,
        clearToast,
        refreshNotifications: fetchNotifications,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) throw new Error('useSocket must be used within a SocketProvider');
  return context;
};
