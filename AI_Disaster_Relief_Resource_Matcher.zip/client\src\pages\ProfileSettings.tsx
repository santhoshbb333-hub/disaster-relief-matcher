import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { User, Settings, Shield, Phone, MapPin, Mail } from 'lucide-react';

export const ProfileSettings: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 border-b border-gray-100 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
            {user?.name ? user.name[0].toUpperCase() : 'U'}
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{user?.name}</h1>
            <p className="text-xs text-blue-700 font-semibold">
              Role: {user?.role.replace('_', ' ')}
            </p>
          </div>
        </div>

        <div className="mt-6 space-y-4 text-xs">
          <h3 className="font-bold text-gray-900 uppercase tracking-wider text-[11px] text-gray-500">Account Details</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center space-x-3">
              <Mail className="w-4 h-4 text-gray-400" />
              <div>
                <div className="text-[10px] text-gray-400 font-bold uppercase">Email Address</div>
                <div className="font-semibold text-gray-900">{user?.email}</div>
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center space-x-3">
              <Phone className="w-4 h-4 text-gray-400" />
              <div>
                <div className="text-[10px] text-gray-400 font-bold uppercase">Phone Number</div>
                <div className="font-semibold text-gray-900">{user?.phone || 'Not configured'}</div>
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center space-x-3">
              <MapPin className="w-4 h-4 text-gray-400" />
              <div>
                <div className="text-[10px] text-gray-400 font-bold uppercase">Base Location</div>
                <div className="font-semibold text-gray-900">{user?.location || 'Coimbatore'}</div>
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center space-x-3">
              <Shield className="w-4 h-4 text-gray-400" />
              <div>
                <div className="text-[10px] text-gray-400 font-bold uppercase">GPS Coordinates</div>
                <div className="font-semibold text-gray-900 font-mono">
                  {user?.latitude || 11.0168}, {user?.longitude || 76.9558}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
