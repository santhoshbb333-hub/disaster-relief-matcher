import React, { useEffect, useState } from 'react';
import { apiRequest } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { useAuth } from '../contexts/AuthContext';
import { Truck, MapPin, Clock, CheckCircle2, ArrowRight } from 'lucide-react';
import { Delivery } from '../types';

export const DeliveriesList: React.FC = () => {
  const { user } = useAuth();
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchDeliveries = async () => {
    try {
      const data = await apiRequest('/deliveries');
      setDeliveries(data.deliveries || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDeliveries();
  }, []);

  const handleUpdateStatus = async (deliveryId: string, nextStatus: string) => {
    setUpdatingId(deliveryId);
    try {
      await apiRequest(`/deliveries/${deliveryId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status: nextStatus }),
      });
      await fetchDeliveries();
    } catch (err: any) {
      alert(err.message || 'Failed to update delivery status');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center">
            <Truck className="w-5 h-5 text-amber-600 mr-2" />
            Volunteer Delivery Management
          </h1>
          <p className="text-xs text-gray-500">
            Track pickup, transit status, and completion of relief resource deliveries to destination rescue centers.
          </p>
        </div>

        {user?.role === 'VOLUNTEER' && (
          <div className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-800 flex items-center">
            <CheckCircle2 className="w-4 h-4 text-amber-600 mr-1.5" />
            Active Volunteer Dispatch Mode
          </div>
        )}
      </div>

      {/* Deliveries Grid */}
      <div className="space-y-4">
        {loading ? (
          <div className="p-12 text-center text-xs text-amber-600 font-semibold">
            Loading volunteer deliveries...
          </div>
        ) : deliveries.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-2xl p-8 text-center text-xs text-gray-500">
            No active deliveries assigned yet.
          </div>
        ) : (
          deliveries.map((del) => {
            const req = del.match?.request;
            const resItem = del.match?.resource;

            return (
              <div
                key={del.id}
                className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4 hover:border-amber-300 transition-colors"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-extrabold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-100">
                        DELIVERY #{del.id.slice(0, 8)}
                      </span>
                      <StatusBadge status={del.status} type="delivery" />
                      {req?.urgency && <StatusBadge status={req.urgency} type="urgency" />}
                    </div>
                    <h3 className="text-base font-bold text-gray-900 mt-1">
                      {del.match?.allocatedQuantity} {req?.unit || 'units'} of {req?.resourceName || resItem?.resourceName}
                    </h3>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] text-gray-400 font-bold uppercase">Estimated ETA</div>
                    <div className="text-sm font-extrabold text-amber-700 flex items-center justify-end">
                      <Clock className="w-3.5 h-3.5 mr-1" />
                      {del.eta} mins ({del.distance} km)
                    </div>
                  </div>
                </div>

                {/* Pickup & Destination Info */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 space-y-1">
                    <div className="text-[10px] font-bold text-gray-400 uppercase">Pickup Location (Donor)</div>
                    <div className="font-bold text-gray-900">{del.pickupLocation}</div>
                    <div className="text-gray-500 text-[11px]">
                      Donor: <strong>{resItem?.donor?.name || del.match?.donor?.name}</strong> • Phone: {resItem?.donor?.phone || 'N/A'}
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 space-y-1">
                    <div className="text-[10px] font-bold text-blue-700 uppercase">Destination (Relief Center)</div>
                    <div className="font-bold text-blue-950">{del.destination}</div>
                    <div className="text-blue-800 text-[11px]">
                      Rescue Team: <strong>{req?.rescueTeam?.name}</strong> • Phone: {req?.rescueTeam?.phone || 'N/A'}
                    </div>
                  </div>
                </div>

                {/* Volunteer Action Buttons */}
                <div className="pt-2 flex items-center justify-between border-t border-gray-100">
                  <div className="text-[11px] text-gray-500">
                    <strong>Volunteer Assigned:</strong> {del.volunteer?.name || 'Unassigned'}
                  </div>

                  <div className="flex items-center space-x-2">
                    {del.status === 'PENDING' && (
                      <button
                        onClick={() => handleUpdateStatus(del.id, 'ASSIGNED')}
                        disabled={updatingId === del.id}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
                      >
                        Accept Delivery Assignment
                      </button>
                    )}

                    {del.status === 'ASSIGNED' && (
                      <button
                        onClick={() => handleUpdateStatus(del.id, 'PICKED_UP')}
                        disabled={updatingId === del.id}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
                      >
                        <MapPin className="w-3.5 h-3.5 mr-1" />
                        Mark as Picked Up
                      </button>
                    )}

                    {del.status === 'PICKED_UP' && (
                      <button
                        onClick={() => handleUpdateStatus(del.id, 'IN_TRANSIT')}
                        disabled={updatingId === del.id}
                        className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
                      >
                        <Truck className="w-3.5 h-3.5 mr-1" />
                        Start Transit (In Transit)
                      </button>
                    )}

                    {del.status === 'IN_TRANSIT' && (
                      <button
                        onClick={() => handleUpdateStatus(del.id, 'DELIVERED')}
                        disabled={updatingId === del.id}
                        className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Mark as Delivered
                      </button>
                    )}

                    {del.status === 'DELIVERED' && (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 flex items-center">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                        Delivery Successfully Completed
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
