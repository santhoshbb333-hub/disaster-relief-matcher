/**
 * Distance and Routing Service
 * Calculates real geographic distance using Haversine formula
 * and estimates delivery transit time.
 */

export interface LocationCoords {
  latitude: number;
  longitude: number;
}

/**
 * Calculates straight-line geographic distance between two points in kilometers using Haversine formula
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const EARTH_RADIUS_KM = 6371;

  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = EARTH_RADIUS_KM * c;

  // Round to 1 decimal place
  return Math.round(distanceKm * 10) / 10;
}

/**
 * Calculates estimated travel time in minutes based on distance and average disaster-terrain speed (35-45 km/h)
 */
export function estimateTravelTimeMinutes(distanceKm: number): number {
  if (distanceKm <= 0) return 5;
  
  // Base driving speed in emergency conditions: ~40 km/h + 5 min pickup buffer
  const speedKmPerHour = 40;
  const hours = distanceKm / speedKmPerHour;
  const minutes = Math.ceil(hours * 60) + 5;
  
  return minutes;
}

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180;
}
