import React from 'react';

interface StatusBadgeProps {
  status: string;
  type?: 'urgency' | 'request' | 'match' | 'delivery' | 'disaster';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, type = 'request' }) => {
  const s = status.toUpperCase();

  let colorClasses = 'bg-gray-100 text-gray-700 border-gray-200';

  if (type === 'urgency') {
    switch (s) {
      case 'CRITICAL':
        colorClasses = 'bg-red-50 text-red-700 border-red-200 font-bold animate-pulse';
        break;
      case 'HIGH':
        colorClasses = 'bg-orange-50 text-orange-700 border-orange-200 font-semibold';
        break;
      case 'MEDIUM':
        colorClasses = 'bg-yellow-50 text-yellow-800 border-yellow-200';
        break;
      case 'LOW':
        colorClasses = 'bg-green-50 text-green-700 border-green-200';
        break;
    }
  } else if (type === 'request' || type === 'match') {
    switch (s) {
      case 'FULLY_MATCHED':
      case 'ACCEPTED':
      case 'COMPLETED':
      case 'AVAILABLE':
        colorClasses = 'bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold';
        break;
      case 'PARTIALLY_MATCHED':
      case 'IN_PROGRESS':
        colorClasses = 'bg-blue-50 text-blue-700 border-blue-200 font-semibold';
        break;
      case 'PENDING':
        colorClasses = 'bg-amber-50 text-amber-700 border-amber-200';
        break;
      case 'REJECTED':
      case 'CANCELLED':
      case 'EXHAUSTED':
        colorClasses = 'bg-rose-50 text-rose-700 border-rose-200';
        break;
    }
  } else if (type === 'delivery') {
    switch (s) {
      case 'DELIVERED':
        colorClasses = 'bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold';
        break;
      case 'IN_TRANSIT':
      case 'PICKED_UP':
        colorClasses = 'bg-blue-50 text-blue-700 border-blue-200 font-semibold';
        break;
      case 'ASSIGNED':
        colorClasses = 'bg-purple-50 text-purple-700 border-purple-200';
        break;
      case 'PENDING':
        colorClasses = 'bg-gray-50 text-gray-700 border-gray-200';
        break;
    }
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${colorClasses}`}
    >
      {s.replace('_', ' ')}
    </span>
  );
};
