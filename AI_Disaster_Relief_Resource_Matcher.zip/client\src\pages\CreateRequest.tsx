import React, { useState } from 'react';
import { apiRequest } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { useOfflineDrafts } from '../hooks/useOfflineDrafts';
import { useGeolocation } from '../hooks/useGeolocation';
import { LocationPermissionModal } from '../components/LocationPermissionModal';
import { FileText, Cpu, AlertTriangle, ArrowRight, MapPin } from 'lucide-react';
import { ResourceType, UrgencyLevel } from '../types';

export const CreateRequest: React.FC = () => {
  const navigate = useNavigate();
  const { isOnline, saveDraft } = useOfflineDrafts();
  const { requestLocationPermission, denyLocationPermission } = useGeolocation();

  const [resourceType, setResourceType] = useState<ResourceType>('Food');
  const [resourceName, setResourceName] = useState('Rice Packets');
  const [requiredQuantity, setRequiredQuantity] = useState('1000');
  const [unit, setUnit] = useState('Packets');
  const [affectedPeople, setAffectedPeople] = useState('800');
  const [urgency, setUrgency] = useState<UrgencyLevel>('CRITICAL');
  const [disasterType, setDisasterType] = useState('Flood');
  const [disasterName, setDisasterName] = useState('Flood Response');
  const [requiredBy, setRequiredBy] = useState(new Date().toISOString().slice(0, 16));
  const [locationName, setLocationName] = useState('Relief Center A - Coimbatore');
  const [latitude, setLatitude] = useState('11.0168');
  const [longitude, setLongitude] = useState('76.9558');
  const [description, setDescription] = useState('Urgent emergency food ration requirement.');
  const [contactPerson, setContactPerson] = useState('');
  const [contactNumber, setContactNumber] = useState('');

  const [showLocationModal, setShowLocationModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleAllowLocation = async () => {
    setShowLocationModal(false);
    const coords = await requestLocationPermission();
    if (coords) {
      setLatitude(coords.latitude.toFixed(4));
      setLongitude(coords.longitude.toFixed(4));
    }
  };

  const handleDenyLocation = () => {
    setShowLocationModal(false);
    denyLocationPermission();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const payload = {
      resourceType,
      resourceName,
      requiredQuantity: parseInt(requiredQuantity, 10),
      unit,
      affectedPeople: parseInt(affectedPeople, 10),
      urgency,
      disasterType,
      disasterName,
      requiredBy,
      locationName,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
      description,
      contactPerson,
      contactNumber,
    };

    if (!isOnline) {
      saveDraft('REQUEST', payload);
      setSubmitting(false);
      alert('Network is offline. Request saved as local draft and queued for auto-syncing!');
      navigate('/requests');
      return;
    }

    try {
      const res = await apiRequest('/requests', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      navigate(`/ai-matching/${res.request.id}`);
    } catch (err: any) {
      setError(err.message || 'Failed to submit request');
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <LocationPermissionModal
        isOpen={showLocationModal}
        onAllow={handleAllowLocation}
        onDeny={handleDenyLocation}
      />

      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 border-b border-gray-100 pb-4">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">Create Emergency Resource Requirement</h1>
            <p className="text-xs text-gray-500">
              Submit your rescue requirement. AI Matching Engine will compare donor resources in the database.
            </p>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs font-semibold text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          {/* Resource Details */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider border-b border-gray-100 pb-2">
              1. Requirement Specification
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Resource Type</label>
                <select
                  value={resourceType}
                  onChange={(e) => setResourceType(e.target.value as ResourceType)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 font-semibold bg-white focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Food">Food</option>
                  <option value="Drinking Water">Drinking Water</option>
                  <option value="Medicine">Medicine</option>
                  <option value="Clothing">Clothing</option>
                  <option value="Blankets">Blankets</option>
                  <option value="Hygiene">Hygiene</option>
                  <option value="Baby Supplies">Baby Supplies</option>
                  <option value="Emergency Equipment">Emergency Equipment</option>
                  <option value="Shelter">Shelter</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Resource Name (Specific Item)</label>
                <input
                  type="text"
                  required
                  value={resourceName}
                  onChange={(e) => setResourceName(e.target.value)}
                  placeholder="e.g. Rice Packets, Drinking Water Bottles"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Required Quantity</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={requiredQuantity}
                  onChange={(e) => setRequiredQuantity(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 font-bold text-blue-700 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Measurement Unit</label>
                <input
                  type="text"
                  required
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="Packets, Bottles, Kits"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Urgency Level</label>
                <select
                  value={urgency}
                  onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-bold text-gray-900 bg-white focus:ring-2 focus:ring-blue-500"
                >
                  <option value="CRITICAL">CRITICAL (Immediate Priority)</option>
                  <option value="HIGH">HIGH (Urgent)</option>
                  <option value="MEDIUM">MEDIUM (Normal)</option>
                  <option value="LOW">LOW (Replenishment)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Location & Permission */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                2. Location & Coordinates
              </h3>
              <button
                type="button"
                onClick={() => setShowLocationModal(true)}
                className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center"
              >
                <MapPin className="w-3.5 h-3.5 mr-1" />
                Use GPS Location
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Relief Center / Destination Name</label>
              <input
                type="text"
                required
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs text-gray-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Latitude</label>
                <input
                  type="text"
                  required
                  value={latitude}
                  onChange={(e) => setLatitude(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono text-gray-900 focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Longitude</label>
                <input
                  type="text"
                  required
                  value={longitude}
                  onChange={(e) => setLongitude(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono text-gray-900 focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/requests')}
              className="px-4 py-2 border border-gray-300 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center"
            >
              <Cpu className="w-4 h-4 mr-2" />
              {submitting ? 'Submitting...' : 'Create Requirement & Run AI Match'}
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
