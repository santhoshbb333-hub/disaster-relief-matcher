import { Router, Response } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticateToken, AuthenticatedRequest } from '../middleware/authMiddleware.js';
import { runAiMatchingForRequest } from '../services/aiMatchingService.js';

const router = Router();

// Create Emergency Resource Request
router.post('/', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      resourceType,
      resourceName,
      requiredQuantity,
      unit,
      affectedPeople,
      urgency,
      disasterType,
      disasterName,
      requiredBy,
      locationName,
      latitude,
      longitude,
      description,
      contactPerson,
      contactNumber,
    } = req.body;

    if (!resourceType || !resourceName || !requiredQuantity || !unit || !urgency || !locationName) {
      return res.status(400).json({ message: 'Missing required request parameters' });
    }

    const qty = parseInt(requiredQuantity, 10);
    const lat = latitude ? parseFloat(latitude) : req.user?.latitude || 11.0168;
    const lng = longitude ? parseFloat(longitude) : req.user?.longitude || 76.9558;

    const request = await prisma.request.create({
      data: {
        rescueTeamId: req.user!.id,
        resourceType,
        resourceName,
        requiredQuantity: qty,
        quantityRemaining: qty,
        unit,
        affectedPeople: affectedPeople ? parseInt(affectedPeople, 10) : 0,
        urgency: urgency.toUpperCase(),
        disasterType: disasterType || 'General Emergency',
        disasterName: disasterName || 'Active Disaster',
        requiredBy: requiredBy ? new Date(requiredBy) : new Date(),
        locationName,
        latitude: lat,
        longitude: lng,
        description: description || '',
        contactPerson: contactPerson || req.user?.name,
        contactNumber: contactNumber || req.user?.phone,
        status: 'PENDING',
      },
    });

    // Create Audit Log entry
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'CREATE_REQUEST',
        entity: 'REQUEST',
        entityId: request.id,
        details: `Created request for ${qty} ${unit} of ${resourceName} (${urgency})`,
      },
    });

    // Automatically trigger AI Matching Engine
    const aiResult = await runAiMatchingForRequest(request.id);

    res.status(201).json({
      message: 'Request created successfully',
      request,
      aiMatchSummary: aiResult,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to create request' });
  }
});

// List Requests with Filters
router.get('/', async (req, res) => {
  try {
    const { status, urgency, resourceType, rescueTeamId } = req.query;

    const whereClause: any = {};
    if (status) whereClause.status = String(status);
    if (urgency) whereClause.urgency = String(urgency);
    if (resourceType) whereClause.resourceType = String(resourceType);
    if (rescueTeamId) whereClause.rescueTeamId = String(rescueTeamId);

    const requests = await prisma.request.findMany({
      where: whereClause,
      include: {
        rescueTeam: {
          select: { id: true, name: true, email: true, phone: true, location: true },
        },
        matches: {
          include: {
            donor: { select: { id: true, name: true, email: true, phone: true } },
            resource: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ requests });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get Request by ID
router.get('/:id', async (req, res) => {
  try {
    const request = await prisma.request.findUnique({
      where: { id: req.params.id },
      include: {
        rescueTeam: true,
        matches: {
          include: {
            donor: true,
            resource: true,
            delivery: true,
          },
        },
      },
    });

    if (!request) {
      return res.status(404).json({ message: 'Request not found' });
    }

    res.json({ request });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Request
router.delete('/:id', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await prisma.request.delete({ where: { id: req.params.id } });
    res.json({ message: 'Request deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
